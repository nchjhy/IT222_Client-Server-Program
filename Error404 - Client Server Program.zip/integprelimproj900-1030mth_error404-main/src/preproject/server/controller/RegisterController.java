package preproject.server.controller;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import preproject.server.model.ScreenType;
import preproject.server.view.RegisterScreen;

import java.awt.event.*;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.UUID;

public class RegisterController implements ActionListener {

    private RegisterScreen registerScreen; // Get access to register screen

    // Constructor
    public RegisterController(RegisterScreen registerScreen) {
        this.registerScreen = registerScreen;
        setupListeners();
    }

    // Setup listeners
    public void setupListeners() {
        registerScreen.getSignUpButton().addActionListener(this);
        registerScreen.getShowPassword().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerScreen.getSignUpButton())
            createAccount();
        else if (e.getSource() == registerScreen.getShowPassword())
            showPassword();
    }

    // Write account to a text file
    private void createAccount() {
        // Fields to get input values
        String firstName = registerScreen.getFirstNameField().getText();
        String lastName = registerScreen.getLastNameField().getText();
        String age = registerScreen.getAgeField().getText();
        String phoneNumber = registerScreen.getPhoneNumberField().getText();
        String email = registerScreen.getEmailField().getText().toLowerCase();
        String password = registerScreen.getPasswordField().getText();
        String cPassword = registerScreen.getConfirmPasswordField().getText();
        boolean isAdmin = false;
        boolean isBanned = false;
        boolean isOnline = false;
        boolean isDelete = false;
        String uniqueID = UUID.randomUUID().toString();

        // Check if first name and last name fields are empty
        if (firstName.isEmpty() || lastName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in your name",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
            // Check if the age is atleast 18 years old
        } else if (Integer.parseInt(age) < 18) {
            JOptionPane.showMessageDialog(null, "Please register with an adult",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
            // Check if phone number is less than 11 characters long and more than 12 characters
        } else if (phoneNumber.length() < 11 || phoneNumber.length() > 11) {
            JOptionPane.showMessageDialog(null, "Please enter a valid phone number",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
            // Check if the email is less than 3 characters long and contains the @ symbol
        } else if (email.length() < 3 && !email.contains("@")) {
            JOptionPane.showMessageDialog(null, "Please enter a valid email address",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
            // Check if passwords match and if the password is atleast 8 characters long
        } else if (!password.equals(cPassword) || password.length() < 8) {
            JOptionPane.showMessageDialog(null, "Please enter a valid password",
                    "Error", JOptionPane.ERROR_MESSAGE);
            registerScreen.getPasswordField().setText(""); // Set password field to blank
            registerScreen.getConfirmPasswordField().setText(""); // Set confirm password field to blank
            return;
        }

        try {
            // Read existing XML file or create a new one if it doesn't exist
            File file = new File("accounts/registration.xml");
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document document;

            if (file.exists()) {
                document = documentBuilder.parse(file);
            } else {
                document = documentBuilder.newDocument();
                Element rootElement = document.createElement("accounts");
                document.appendChild(rootElement);
            }

            // Check if the email already exists in the XML file
            NodeList nodeList = document.getElementsByTagName("account");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    String existingEmail = element.getElementsByTagName("email").item(0).getTextContent();
                    if (email.equalsIgnoreCase(existingEmail)) {
                        JOptionPane.showMessageDialog(null, "Email already exists", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Create new account element
            Element account = document.createElement("account");
            Element firstNameElement = document.createElement("firstName");
            firstNameElement.appendChild(document.createTextNode(firstName));
            account.appendChild(firstNameElement);

            Element lastNameElement = document.createElement("lastName");
            lastNameElement.appendChild(document.createTextNode(lastName));
            account.appendChild(lastNameElement);

            Element ageElement = document.createElement("age");
            ageElement.appendChild(document.createTextNode(age));
            account.appendChild(ageElement);

            Element phoneNumberElement = document.createElement("phoneNumber");
            phoneNumberElement.appendChild(document.createTextNode(phoneNumber));
            account.appendChild(phoneNumberElement);

            Element emailElement = document.createElement("email");
            emailElement.appendChild(document.createTextNode(email));
            account.appendChild(emailElement);

            Element passwordElement = document.createElement("password");
            passwordElement.appendChild(document.createTextNode(password));
            account.appendChild(passwordElement);

            Element isAdminElement = document.createElement("isAdmin");
            isAdminElement.appendChild(document.createTextNode(String.valueOf(isAdmin)));
            account.appendChild(isAdminElement);

            Element isBannedElement = document.createElement("isBanned");
            isBannedElement.appendChild(document.createTextNode(String.valueOf(isBanned)));
            account.appendChild(isBannedElement);

            Element isOnlineElement = document.createElement("isOnline");
            isOnlineElement.appendChild(document.createTextNode(String.valueOf(isOnline)));
            account.appendChild(isOnlineElement);

            Element isDeleteElement = document.createElement("isDelete");
            isDeleteElement.appendChild(document.createTextNode(String.valueOf(isDelete)));
            account.appendChild(isDeleteElement);

            Element uniqueIDElement = document.createElement("uniqueID");
            uniqueIDElement.appendChild(document.createTextNode(uniqueID));
            account.appendChild(uniqueIDElement);

            // Append account to root element
            document.getDocumentElement().appendChild(account);

            // Write to XML file
            FileWriter writer = new FileWriter(file);
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(writer);
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source,result);
            writer.flush();
            writer.close();

            JOptionPane.showMessageDialog(null, "Hello " + firstName + "! Your account has been created");

            // Switch to login screen
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.LOGIN_SCREEN.getValue()]);

        } catch (Exception e) {
            System.err.println("An error occurred: " + e);
        }
    }

    // Show and hide password
    private void showPassword() {
        if (registerScreen.getShowPassword().isSelected()) {
            registerScreen.getPasswordField().setEchoChar((char) 0);
            registerScreen.getConfirmPasswordField().setEchoChar((char) 0);
        } else {
            registerScreen.getPasswordField().setEchoChar('•');
            registerScreen.getConfirmPasswordField().setEchoChar('•');
        }
    }
}
