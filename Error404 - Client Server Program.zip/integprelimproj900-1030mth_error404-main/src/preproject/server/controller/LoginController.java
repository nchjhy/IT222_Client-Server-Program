package preproject.server.controller;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import preproject.client.controller.ClientHomeController;
import preproject.client.view.ClientHomeScreen;
import preproject.server.model.Account;
import preproject.server.model.ScreenType;
import preproject.server.view.AdminHomeScreen;
import preproject.server.view.LoginScreen;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
public class LoginController implements ActionListener {

    private LoginScreen loginScreen; // Access login screen
    private String emailInput; // Get email input

    // Constructor
    public LoginController(LoginScreen loginScreen) {
        this.loginScreen = loginScreen;
        setupListeners();
    }

    // Setup listeners
    public void setupListeners() {
        loginScreen.getLoginButton().addActionListener(this);
        loginScreen.getRegisterButton().addActionListener(this);
        loginScreen.getShowPassword().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginScreen.getLoginButton()) { // User clicked login button
            loginAccount(); // Call loginAccount method
            // ApplicationController.switchScreen
            //         (ApplicationController.screens[ScreenType.CLIENTHOME_SCREEN.getValue()]);
        } else if (e.getSource() == loginScreen.getRegisterButton()) { // User clicked register button
            // Switch to register screen
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.REGISTER_SCREEN.getValue()]);
        } else if (e.getSource() == loginScreen.getShowPassword()) // User checked show password box
            showPassword();
    }

    // Logging into account by reading file
    // Check if the inputted account exists and set the account information to the current account
    private void loginAccount() {
        boolean accountFound = false; // Mark when an account is logged in
        emailInput = loginScreen.getEmailField().getText().toLowerCase(); // Get email input
        String passwordInput = loginScreen.getPasswordField().getText(); // Get password input
        boolean isBan = false;

        try {
            String filePath = "accounts" + File.separator + "registration.xml";
            File file = new File(filePath);

            // Check if the file exists; if not, create it
            if (!file.exists()) {
                file.getParentFile().mkdirs(); // Create parent directories if they don't exist
                file.createNewFile(); // Create the file
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("account");

            // Iterate through the list of accounts
            for (int i = 0; i < nodeList.getLength() && !accountFound; i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    // Check if the user input matches the email and password in the XML
                    String email = element.getElementsByTagName("email").item(0).getTextContent();
                    String password = element.getElementsByTagName("password").item(0).getTextContent();
                    boolean isBanned = Boolean.parseBoolean(element.getElementsByTagName("isBanned").item(0).getTextContent());
                    boolean isOnline = Boolean.parseBoolean(element.getElementsByTagName("isOnline").item(0).getTextContent());
                    if (email.equals(emailInput) && password.equals(passwordInput) && !isBanned) {
                        onlineSelectedUser(i);
                        accountFound = true; // Found account login

                        // Switch to home screen based on admin status
                        boolean isAdmin = Boolean.parseBoolean(element.getElementsByTagName("isAdmin").item(0).getTextContent());
                        if (isAdmin) {
                            if (ApplicationController.adminHomeController == null) {
                                ApplicationController.adminHomeController = new AdminHomeController((AdminHomeScreen) ApplicationController.screens[ScreenType.ADMINHOME_SCREEN.getValue()]);
                            }
                            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.ADMINHOME_SCREEN.getValue()]);
                            ApplicationController.adminHomeController.setupLabel();
                        } else {
                            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.CLIENTHOME_SCREEN.getValue()]);
                            if (ApplicationController.clientHomeController == null) {
                                ApplicationController.clientHomeController = new ClientHomeController((ClientHomeScreen) ApplicationController.screens[ScreenType.CLIENTHOME_SCREEN.getValue()]);
                            }
                            ApplicationController.clientHomeController.setupLabel();
                        }

                        // Retrieve account information
                        ApplicationController.currentFirstName = element.getElementsByTagName("firstName").item(0).getTextContent();
                        ApplicationController.currentLastName = element.getElementsByTagName("lastName").item(0).getTextContent();
                        ApplicationController.currentAge = element.getElementsByTagName("age").item(0).getTextContent();
                        ApplicationController.currentPhoneNumber = element.getElementsByTagName("phoneNumber").item(0).getTextContent();
                        ApplicationController.currentEmail = emailInput;
                        ApplicationController.currentAdminStatus = isAdmin;
                        ApplicationController.currentBanStatus = Boolean.parseBoolean(element.getElementsByTagName("isBanned").item(0).getTextContent());
                        ApplicationController.currentOnlineStatus = true;
                        ApplicationController.currentID = element.getElementsByTagName("uniqueID").item(0).getTextContent();
                        System.out.println("Admin status: " + ApplicationController.currentAdminStatus);
                        if (isAdmin) {
                            ApplicationController.adminHomeController.setupLabel();
                        } else {
                            ApplicationController.clientHomeController.setupLabel();
                        }
                        ApplicationController.profileController.setupLabel();

                        Account account = ApplicationController.accounts.get(i);
                        // account.setAdmin(ApplicationController.currentAdminStatus);
                        // account.setAge(ApplicationController.currentAge);
                        // account.setBanned(ApplicationController.currentBanStatus);
                        // account.setDelete(ApplicationController.currentDeleteStatus);
                        // account.setEmail(ApplicationController.currentEmail);
                        // account.setFirstName(ApplicationController.currentFirstName);
                        // account.setLastName(ApplicationController.currentLastName);
                        account.setOnline(ApplicationController.currentOnlineStatus);

                        // Reload imports
                        ApplicationController.appointmentImport.importAppointments("accounts/appointments.xml");

                        // Show login prompt
                        JOptionPane.showMessageDialog(null, "Login successful", "Welcome", JOptionPane.INFORMATION_MESSAGE);
                    }
                    if (email.equals(emailInput) && !password.equals(passwordInput) && !isBanned) {
                        JOptionPane.showMessageDialog(null, "Invalid login\nPlease check your email and password", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    if (email.equals(emailInput) && isBanned) {
                        isBan = true;
                        JOptionPane.showMessageDialog(null, "Invalid login\nAccount is banned", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    if (email.equals(emailInput) && isOnline) {
                        isOnline = true;
                        JOptionPane.showMessageDialog(null, "Invalid login\nAccount is already online", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

            // Show error message if an account is not found
            if (!accountFound && !isBan) {
                JOptionPane.showMessageDialog(null, "Invalid login\nAccount not found", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
    }

    // Show and hide password
    private void showPassword() {
        if (loginScreen.getShowPassword().isSelected())
            loginScreen.getPasswordField().setEchoChar((char) 0);
        else
            loginScreen.getPasswordField().setEchoChar('•');
    }
    private void onlineSelectedUser(int i) {
        // Get the selected row from the table
        Account selectedUser = ApplicationController.accounts.get(i);
        if (selectedUser.isOnline()){
            selectedUser.setOnline(true);
        }
    }
}
