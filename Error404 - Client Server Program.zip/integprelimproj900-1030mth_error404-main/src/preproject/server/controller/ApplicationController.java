package preproject.server.controller;

import javax.swing.*;

import preproject.client.controller.ClientBookingHistoryController;
import preproject.client.controller.ClientHomeController;
import preproject.client.view.ClientBookingHistoryScreen;
import preproject.client.view.ClientHomeScreen;
import preproject.server.model.Account;
import preproject.server.model.Booking;
import preproject.server.model.ScreenType;
import preproject.server.view.*;

import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ApplicationController {

    private static ObjectOutputStream serverStream;

    private static DefaultScreen defaultScreen; // Access DefaultScreen

    public static Screen[] screens = new Screen[ScreenType.values().length]; // All screens
    public static LoginController loginController; // Access LoginController
    public static AdminHomeController adminHomeController; // Access AdminHomeController
    public static ClientHomeController clientHomeController; // Access ClientHomeController
    public static CheckinController checkinController; // Access BookingController
    public static ProfileController profileController; // Access ProfileController
    public static AnnouncementController announcementController; // Access AnnoucementController
    public static CheckoutController checkoutController; // Access CheckoutController
    public static CancelBookingController cancelBookingController; // Access CancelBookingCotroller
    public static GuestController guestController; // Access GuestController
    public static BookingHistoryController bookingHistoryController; // Access BookingHistoryController
    public static UserController userController; // Access UserController
    public static ClientBookingHistoryController clientBookingHistoryController; // Access ClientBookingHistoryController

    public static String currentFirstName; // Logged in users first name
    public static String currentLastName; // Logged in users last name
    public static String currentAge; // Logged in users age
    public static String currentPhoneNumber; // Logged in users phone number
    public static String currentEmail; // Logged in users email
    public static boolean currentAdminStatus; // Logged in users admin status
    public static boolean currentBanStatus; // Logged in users ban status
    public static String currentID; // Logged in users ID
    public static boolean currentOnlineStatus;
    public static boolean currentDeleteStatus;

    public static AccountController accountImport = new AccountController(); // Import accounts
    public static AppointmentController appointmentImport = new AppointmentController(); // Import appointments
    public static AccountController onlineAccountsImport = new AccountController(); // Import accounts
    public static AccountController deleteAccountsImport = new AccountController();


    public static ArrayList<Account> accounts = new ArrayList(); // Store accounts into ArrayList
    public static ArrayList<Booking> appointments = new ArrayList(); // Store appointments into ArrayList
    public static ArrayList<Booking> currentAppointments = new ArrayList(); // Store appointments for current user
    public static ArrayList<Account> onlineAccounts = new ArrayList<>();
    public static ArrayList<Account> deleteAccounts = new ArrayList<>();

    public static DefaultListModel<Booking> appointmentListModel = new DefaultListModel<>();



    public ApplicationController(ObjectOutputStream stream) {
        serverStream = stream;

        // Import account data
        accountImport.importAccounts("accounts/registration.xml");
        onlineAccountsImport.loadOnlineAccounts("accounts/online.xml");
        deleteAccountsImport.loadDeleteAccounts("accounts/deletedAccounts.xml");

        // Create default screen object
        defaultScreen = new DefaultScreen();

        // Create all screens
        screens[ScreenType.LOGIN_SCREEN.getValue()] = new LoginScreen();
        screens[ScreenType.REGISTER_SCREEN.getValue()] = new RegisterScreen();
        screens[ScreenType.ADMINHOME_SCREEN.getValue()] = new AdminHomeScreen();
        screens[ScreenType.CLIENTHOME_SCREEN.getValue()] = new ClientHomeScreen();
        screens[ScreenType.CHECKIN_SCREEN.getValue()] = new CheckinScreen();
        screens[ScreenType.VIEW_APPOINTMENTS_SCREEN.getValue()] = new ViewAppointmentsScreen();
        screens[ScreenType.PROFILE_SCREEN.getValue()] = new ProfileScreen();
        screens[ScreenType.ANNOUNCEMENT_SCREEN.getValue()] = new AnnouncementScreen();
        screens[ScreenType.CHECKOUT_SCREEN.getValue()] = new CheckoutScreen();
        screens[ScreenType.CANCELBOOKING_SCREEN.getValue()] = new CancelBookingScreen();
        screens[ScreenType.BOOKINGHISTORY_SCREEN.getValue()] = new BookingHistoryScreen();
        screens[ScreenType.GUEST_SCREEN.getValue()] = new GuestScreen();        
        screens[ScreenType.USER_SCREEN.getValue()] = new UserScreen();
        screens[ScreenType.CLIENTBOOKINGHISTORY_SCREEN.getValue()] = new ClientBookingHistoryScreen();

    // Create controllers
    loginController = new LoginController((LoginScreen) screens[ScreenType.LOGIN_SCREEN.getValue()]);
    new RegisterController((RegisterScreen) screens[ScreenType.REGISTER_SCREEN.getValue()]);

    if (currentAdminStatus) {
        adminHomeController = new AdminHomeController((AdminHomeScreen) screens[ScreenType.ADMINHOME_SCREEN.getValue()]);
    } else {
        clientHomeController = new ClientHomeController((ClientHomeScreen) screens[ScreenType.CLIENTHOME_SCREEN.getValue()]);
    }

    checkinController = new CheckinController((CheckinScreen) screens[ScreenType.CHECKIN_SCREEN.getValue()]);
    profileController = new ProfileController((ProfileScreen) screens[ScreenType.PROFILE_SCREEN.getValue()]);
    announcementController = new AnnouncementController((AnnouncementScreen) screens[ScreenType.ANNOUNCEMENT_SCREEN.getValue()],serverStream);
    checkoutController = new CheckoutController((CheckoutScreen) screens[ScreenType.CHECKOUT_SCREEN.getValue()]);
    cancelBookingController = new CancelBookingController((CancelBookingScreen) screens[ScreenType.CANCELBOOKING_SCREEN.getValue()]);
    bookingHistoryController = new BookingHistoryController((BookingHistoryScreen) screens[ScreenType.BOOKINGHISTORY_SCREEN.getValue()]);
    guestController = new GuestController((GuestScreen) screens[ScreenType.GUEST_SCREEN.getValue()]);
    userController = new UserController((UserScreen) screens[ScreenType.USER_SCREEN.getValue()]);
    clientBookingHistoryController = new ClientBookingHistoryController((ClientBookingHistoryScreen) screens[ScreenType.CLIENTBOOKINGHISTORY_SCREEN.getValue()]);

    // Setup back buttons
    setupBackButton();

    // Login screen set to initial screen
    defaultScreen.add(screens[ScreenType.LOGIN_SCREEN.getValue()]);
    defaultScreen.setVisible(true);

    System.out.println("Start Application");
}


    // Setting up back buttons
    public void setupBackButton() {
        for (int x = 0; x < ScreenType.values().length; x++) {
            if (screens[x] != null) {
                // Switching to login screen
                screens[x].getBackButton().addActionListener(e ->
                        switchScreen(screens[ScreenType.LOGIN_SCREEN.getValue()])
                );

                // Switching to home screen
                screens[x].getBackToHomeButton().addActionListener(e -> {
                    if (currentAdminStatus) {
                        switchScreen(screens[ScreenType.ADMINHOME_SCREEN.getValue()]);
                    } else {
                        switchScreen(screens[ScreenType.CLIENTHOME_SCREEN.getValue()]);
                    }
                });
            } else {
                System.out.println("Screen at index " + x + " is null.");
            }
        }
    }


    // Method to switch screens
    public static void switchScreen(JPanel newScreen) {
        System.out.println("Switching to screen: " + newScreen.getClass().getSimpleName());
        defaultScreen.getContentPane().removeAll();
        defaultScreen.getContentPane().repaint();
        defaultScreen.getContentPane().add(newScreen);
        defaultScreen.revalidate(); 
        defaultScreen.repaint();
    }
    public static void setServerStream(ObjectOutputStream stream) {
        serverStream = stream;
    }
    }

