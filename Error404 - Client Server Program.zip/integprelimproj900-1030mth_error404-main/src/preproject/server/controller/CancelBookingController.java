package preproject.server.controller;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import preproject.server.model.Booking;
import preproject.server.view.CancelBookingScreen;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CancelBookingController implements ActionListener {

    private CancelBookingScreen cancelBookingScreen;

    public CancelBookingController(CancelBookingScreen cancelBookingScreen) {
        this.cancelBookingScreen = cancelBookingScreen;

        cancelBookingScreen.getClearButton().addActionListener(this);
        cancelBookingScreen.getCancelBookingButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancelBookingScreen.getClearButton()) {
            clearFields();
        } else if (e.getSource() == cancelBookingScreen.getCancelBookingButton()) {
            cancelBooking();
            clearFields();
        }
    }

    private List<Booking> loadAppointments() {
        List<Booking> appointments = new ArrayList<>();

        try {
            // Parse the XML file
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File("accounts/appointments.xml"));

            // Get the appointments nodes
            NodeList appointmentNodes = doc.getElementsByTagName("appointment");

            // Loop through each appointment node
            for (int i = 0; i < appointmentNodes.getLength(); i++) {
                Element appointmentElement = (Element) appointmentNodes.item(i);

                // Get appointment information from XML elements
                String firstName = getElementTextContent(appointmentElement, "firstName");
                String lastName = getElementTextContent(appointmentElement, "lastName");
                String phoneNumber = getElementTextContent(appointmentElement, "phoneNumber");
                String emailAddress = getElementTextContent(appointmentElement, "email");
                String checkInDate = getElementTextContent(appointmentElement, "checkInDate");
                String checkOutDate = getElementTextContent(appointmentElement, "checkOutDate");
                String roomCapacity = getElementTextContent(appointmentElement, "roomCapacity");
                String uniqueID = getElementTextContent(appointmentElement, "uniqueID");

                // Create a new Booking object and add it to the appointments list
                Booking booking = new Booking(firstName, lastName, phoneNumber, emailAddress,
                        checkInDate, checkOutDate,roomCapacity, uniqueID);
                appointments.add(booking);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return appointments;
    }

    private String getElementTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        } else {
            return "";
        }
    }

    private void clearFields() {
        cancelBookingScreen.clearFields();
    }

    private void cancelBooking() {
        // Get the details of the booking to be canceled
        String firstName = cancelBookingScreen.getFirstName().trim();
        String lastName = cancelBookingScreen.getLastName().trim();
        String email = cancelBookingScreen.getEmail().trim();

        // Load the existing appointments from the XML file
        List<Booking> appointments = loadAppointments();

        // Find the booking to cancel based on provided details
        Booking bookingToCancel = null;
        for (Booking booking : appointments) {
            if (booking.getFirstName().trim().equalsIgnoreCase(firstName)
                    && booking.getLastName().trim().equalsIgnoreCase(lastName)
                    && booking.getEmailAddress().equalsIgnoreCase(email)) {
                bookingToCancel = booking;
                break;
            }
        }

        // Cancel the booking if found
        if (bookingToCancel != null) {
            appointments.remove(bookingToCancel);
            saveAppointmentsToXml(appointments); // Save the updated appointments to XML
            JOptionPane.showMessageDialog(cancelBookingScreen, "Booking Canceled");
        } else {
            JOptionPane.showMessageDialog(cancelBookingScreen, "Booking not found", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void saveAppointmentsToXml(List<Booking> appointments) {
        try {
            // Create a new Document
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // Create the root element
            Element rootElement = doc.createElement("appointments");
            doc.appendChild(rootElement);

            // Create appointment elements for each booking
            for (Booking booking : appointments) {
                Element appointmentElement = doc.createElement("appointment");

                appendXmlElement(doc, appointmentElement, "firstName", booking.getFirstName());
                appendXmlElement(doc, appointmentElement, "lastName", booking.getLastName());
                appendXmlElement(doc, appointmentElement, "phoneNumber", booking.getPhoneNumber());
                appendXmlElement(doc, appointmentElement, "email", booking.getEmailAddress());
                appendXmlElement(doc, appointmentElement, "checkInDate", booking.getCheck_in_date());
                appendXmlElement(doc, appointmentElement, "checkOutDate", booking.getCheck_out_date());
                appendXmlElement(doc, appointmentElement, "roomCapacity", booking.getRoomCapacity());
                appendXmlElement(doc, appointmentElement, "uniqueID", booking.getUniqueID());

                rootElement.appendChild(appointmentElement);
            }

            // Save the updated XML to file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new FileOutputStream("accounts/appointments.xml"));

            transformer.transform(source, result);
        } catch (ParserConfigurationException | IOException | TransformerException e) {
            e.printStackTrace();
        }
    }


    private void appendXmlElement(Document doc, Element parent, String tagName, String textContent) {
        Element element = doc.createElement(tagName);
        element.appendChild(doc.createTextNode(textContent));
        parent.appendChild(element);
    }
}