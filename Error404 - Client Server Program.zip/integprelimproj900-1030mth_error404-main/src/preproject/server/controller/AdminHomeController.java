package preproject.server.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import preproject.server.model.ScreenType;
import preproject.server.view.AdminHomeScreen;

public class AdminHomeController implements ActionListener {

    private AdminHomeScreen adminHomeScreen; // Access home screen

    // Constructor
    public AdminHomeController(AdminHomeScreen adminHomeScreen) {
        this.adminHomeScreen = adminHomeScreen;
        setupListeners();
    }

    // Welcome label with accounts first name
    public void setupLabel() { 
        adminHomeScreen.getWelcomeLabel().setText("Welcome, " + ApplicationController.currentFirstName + "!");
        System.out.println("isOnline: " + ApplicationController.currentOnlineStatus);
    }

    // Set up listeners
    public void setupListeners() {
        adminHomeScreen.getAppointmentButton().addActionListener(this);
        adminHomeScreen.getViewAppointmentButton().addActionListener(this);
        adminHomeScreen.getProfileButton().addActionListener(this);
        adminHomeScreen.getBookingHistoryButton().addActionListener(this);
        adminHomeScreen.getAnnouncementButton().addActionListener(this);
        adminHomeScreen.getGuestButton().addActionListener(this);
        adminHomeScreen.getLogoutButton().addActionListener((this));
        adminHomeScreen.getUserButton().addActionListener((this));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminHomeScreen.getAppointmentButton()) {
            // Ask admin whether to add or delete booking
            showBookingOptionDialog();
        } else if (e.getSource() == adminHomeScreen.getBackButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.ADMINHOME_SCREEN.getValue()]);
        } else if (e.getSource() == adminHomeScreen.getViewAppointmentButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.VIEW_APPOINTMENTS_SCREEN.getValue()]);
            ApplicationController.appointmentListModel.clear();
            ApplicationController.appointmentListModel.addAll(ApplicationController.currentAppointments);
        } else if (e.getSource() == adminHomeScreen.getBookingHistoryButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.BOOKINGHISTORY_SCREEN.getValue()]);
        } else if (e.getSource() == adminHomeScreen.getAnnouncementButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.ANNOUNCEMENT_SCREEN.getValue()]);
        } else if (e.getSource() == adminHomeScreen.getProfileButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.PROFILE_SCREEN.getValue()]);
        } else if (e.getSource() == adminHomeScreen.getLogoutButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.LOGIN_SCREEN.getValue()]);
        } else if (e.getSource() == adminHomeScreen.getGuestButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.GUEST_SCREEN.getValue()]);
        } else if (e.getSource() == adminHomeScreen.getUserButton()) {
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.USER_SCREEN.getValue()]);
        }
    }
    
    private void showBookingOptionDialog() {
        Object[] options = {"Add Booking", "Cancel Booking"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Do you want to add or cancel a booking?",
                "Booking Option",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
    
        if (choice == JOptionPane.YES_OPTION) {
             // Add Booking option selected
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.CHECKIN_SCREEN.getValue()]);
            JOptionPane.showMessageDialog(
                null,
                "Add Booking option selected",
                "Info",
                JOptionPane.INFORMATION_MESSAGE);

        } else if (choice == JOptionPane.NO_OPTION) {
             // Add Canceloption selected
            ApplicationController.switchScreen(ApplicationController.screens[ScreenType.CANCELBOOKING_SCREEN.getValue()]);
            JOptionPane.showMessageDialog(
                    null,
                    "Cancel Booking option selected",
                    "Info",
                    JOptionPane.INFORMATION_MESSAGE);

        }
    }
    


   
}



    


