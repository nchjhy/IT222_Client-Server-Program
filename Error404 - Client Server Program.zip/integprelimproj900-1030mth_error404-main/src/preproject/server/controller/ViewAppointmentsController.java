package preproject.server.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import preproject.server.model.Booking;
import preproject.server.view.ViewAppointmentsScreen;

public class ViewAppointmentsController implements ActionListener {
    private ViewAppointmentsScreen viewAppointmentsScreen;

    public ViewAppointmentsController(ViewAppointmentsScreen viewAppointmentsScreen) {
        this.viewAppointmentsScreen = viewAppointmentsScreen;
        loadAppointments();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle actions if needed
    }

    // Method to load appointments from XML and update the view
    private void loadAppointments() {
        try {
            List<Booking> appointments = new ArrayList<>();
    
            // Parse the XML file
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File("accounts/appointments.xml"));
    
            // Get the appointments nodes
            NodeList appointmentNodes = doc.getElementsByTagName("appointment");
    
            // Clear existing data in the table model
            clearTableModel();
    
            // Loop through each appointment node
            for (int i = 0; i < appointmentNodes.getLength(); i++) {
                Node appointmentNode = appointmentNodes.item(i);
                if (appointmentNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element appointmentElement = (Element) appointmentNode;
    
                    // Get appointment information from XML elements
                    String firstName = getElementTextContent(appointmentElement, "firstName");
                    String lastName = getElementTextContent(appointmentElement, "lastName");
                    String phoneNumber = getElementTextContent(appointmentElement, "phoneNumber");
                    String emailAddress = getElementTextContent(appointmentElement, "email");
                    String checkInDate = getElementTextContent(appointmentElement, "checkInDate");
                    String checkOutDate = getElementTextContent(appointmentElement, "checkOutDate");
                    String roomCapacity = getElementTextContent(appointmentElement, "roomCapacity");
                    String uniqueID = getElementTextContent(appointmentElement, "uniqueID");
    
                    // Create a new Booking object and add it to the appointments list
                    Booking booking = new Booking(firstName, lastName, phoneNumber, emailAddress,
                            checkInDate, checkOutDate, roomCapacity, uniqueID);
                    appointments.add(booking);
    
                    // Add a row to the table model with the booking details
                    viewAppointmentsScreen.getTableModel().addRow(new Object[]{firstName, lastName, phoneNumber, emailAddress, checkInDate, checkOutDate, roomCapacity, uniqueID});
                }
            }
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    private void clearTableModel() {
        // Remove all rows from the table model
        DefaultTableModel tableModel = viewAppointmentsScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    }

    private String getElementTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        } else {
            return "";
        }
    }
}
