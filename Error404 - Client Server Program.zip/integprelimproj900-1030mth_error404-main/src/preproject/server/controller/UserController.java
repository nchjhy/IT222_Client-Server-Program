package preproject.server.controller;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import preproject.server.model.Account;
import preproject.server.view.UserScreen;

public class UserController implements ActionListener {
    private UserScreen userScreen;
  
    public UserController(UserScreen userScreen) {
        this.userScreen = userScreen;

        // Attach ActionListener to the search button
        userScreen.addSearchButtonListener(this);
        // Attach ActionListener to the ban button
        userScreen.addBanButtonListener(this);
        // Attach ActionListener to the unban button
        userScreen.addUnbanButtonListener(this);
        // Attach ActionListener to the delete button
        userScreen.addDeleteButtonListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == userScreen.getSearchButton()) {
            // Perform search based on the entered keyword
            String keyword = userScreen.getSearchKeyword();
            searchByEmail(keyword);
        } else if (e.getSource() == userScreen.getBanButton()) {
            banSelectedUser();
        } else if (e.getSource() == userScreen.getUnbanButton()) {
            unbanSelectedUser();
        } else if (e.getSource() == userScreen.getDeleteButton()) {
            deleteSelectedUser();
        }
    }
    private void searchByEmail(String emailKeyword) {
        DefaultTableModel tableModel = (DefaultTableModel) userScreen.getTable().getModel();
        tableModel.setRowCount(0); // Clear existing rows in the table
    
        if (emailKeyword.isEmpty()) {
            updateTableModel(emailKeyword);
        } else {
            for (Account account : ApplicationController.accounts) {
                if (account.getEmail().contains(emailKeyword)) {
                    tableModel.addRow(new Object[]{
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmail(),
                            account.isAdmin(),
                            account.isBanned(),
                            account.isOnline(),
                            account.isDelete()
                    });
                }
            }
        }
    }

      private void updateOnlineStatus() {
        AccountController accountController = new AccountController();
        accountController.updateOnlineStatus();
    }

    private void banUserInXML(String email, boolean isBanned) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new File("accounts/registration.xml"));
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("account");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);
    
                // Check if the email matches
                if (element.getElementsByTagName("email").item(0).getTextContent().equals(email)) {
                    // Update the isBanned attribute
                    element.getElementsByTagName("isBanned").item(0).setTextContent(String.valueOf(isBanned));
                    break; // No need to continue searching
                }
            }
    
            // Save the changes back to the XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("accounts/registration.xml"));
    
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
    
            // Update online status immediately after banning
            updateOnlineStatus();
    
        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }
    }
    
    private void unbanUserInXML(String email, boolean isBanned) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new File("accounts/registration.xml"));
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("account");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);
    
                // Check if the email matches
                if (element.getElementsByTagName("email").item(0).getTextContent().equals(email)) {
                    // Update the isBanned attribute
                    element.getElementsByTagName("isBanned").item(0).setTextContent(String.valueOf(isBanned));
                    break;
                }
            }
    
            // Save the changes back to the XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("accounts/registration.xml"));
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
    
            // Update online status immediately after unbanning
            updateOnlineStatus();
    
        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }
    }
    
    private void banSelectedUser() {
        // Get the selected row from the table
        int selectedRow = userScreen.getTable().getSelectedRow();
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) userScreen.getTable().getValueAt(selectedRow, 3);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(userScreen, "Are you sure you want to ban the user with email: " + email + "?", "Confirm Ban", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                userScreen.getTable().setValueAt(true, selectedRow, 5);
            }
            if (option == JOptionPane.YES_OPTION) {
                userScreen.getTable().setValueAt(true, selectedRow, 5);
                // Call the method to update XML
                banUserInXML(email, true);
            }
        } else {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(userScreen, "Please select a user to ban.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void unbanSelectedUser() {
        int selectedRow = userScreen.getTable().getSelectedRow();
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) userScreen.getTable().getValueAt(selectedRow, 3);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(userScreen, "Are you sure you want to unban the user with email: " + email + "?", "Confirm Unban", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                userScreen.getTable().setValueAt(false, selectedRow, 5);
            }
            if (option == JOptionPane.YES_OPTION) {
                userScreen.getTable().setValueAt(false, selectedRow, 5);
                // Call the method to update XML
                unbanUserInXML(email, false);
            }
        } else {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(userScreen, "Please select a user to unban.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void deleteSelectedUser() {
        int selectedRow = userScreen.getTable().getSelectedRow();
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) userScreen.getTable().getValueAt(selectedRow, 3);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(userScreen, "Are you sure you want to delete the user with email: " + email + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                deleteUserFromXML(email);
                // Remove the user from the accounts list
                ApplicationController.accounts.removeIf(account -> account.getEmail().equals(email));
                updateTableModel(userScreen.getSearchKeyword());
            }
        } else {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(userScreen, "Please select a user to delete.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
    }
    

    private void deleteUserFromXML(String email) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new File("accounts/registration.xml"));
            doc.getDocumentElement().normalize();
    
            NodeList nodeList = doc.getElementsByTagName("account");
    
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);
    
                // Check if the email matches
                if (element.getElementsByTagName("email").item(0).getTextContent().equals(email)) {
                    // Remove the account node from the parent
                    element.getParentNode().removeChild(element);
                    break; 
                }
            }
    
            // Save the changes back to the XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("accounts/registration.xml"));
    
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
    
        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            e.printStackTrace();
        }
    }
    

    private void clearTableModel() {
        DefaultTableModel tableModel = (DefaultTableModel) userScreen.getTable().getModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    }

    private void updateTableModel(String keyword) {
        clearTableModel();

        DefaultTableModel tableModel = (DefaultTableModel) userScreen.getTable().getModel();
    
        for (Account account : ApplicationController.accounts) {
            String firstName = account.getFirstName();
            String lastName = account.getLastName();
            String phoneNumber = account.getPhoneNumber();
            String email = account.getEmail();
            boolean isAdmin = account.isAdmin();
            boolean isBanned = account.isBanned();
            boolean isOnline = account.isOnline();
            boolean isDelete = account.isDelete();
    
            // Check if the account matches the search keyword
            if (keyword.isEmpty() || email.contains(keyword) || lastName.contains(keyword)) {
    
                // Add a row to the table model with the account details
                tableModel.addRow(new Object[]{firstName, lastName, phoneNumber, email, isAdmin, isBanned, isOnline, isDelete});
            }
        }
    }

}

