package preproject.server.controller;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import preproject.server.model.Booking;

public class AppointmentController {

    public void importAppointments(String fileName) {
        try {
            // Create a DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            // Parse the XML file
            Document doc = builder.parse(new File(fileName));

            // Get the appointments nodes
            NodeList appointmentNodes = doc.getElementsByTagName("appointment");

            // Loop through each appointment node
            for (int i = 0; i < appointmentNodes.getLength(); i++) {
                Node appointmentNode = appointmentNodes.item(i);
                if (appointmentNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element appointmentElement = (Element) appointmentNode;

                    // Get appointment information from XML elements
                    String firstName = getElementTextContent(appointmentElement, "firstName");
                    String lastName = getElementTextContent(appointmentElement, "lastName");
                    String phoneNumber = getElementTextContent(appointmentElement, "phoneNumber");
                    String emailAddress = getElementTextContent(appointmentElement, "emailAddress");
                    String checkInDate = getElementTextContent(appointmentElement, "checkInDate");
                    String checkOutDate = getElementTextContent(appointmentElement, "checkOutDate");
                    String roomCapacity = getElementTextContent(appointmentElement, "roomCapacity");
                    String uniqueID = getElementTextContent(appointmentElement, "uniqueID");

                    // Create a new Booking object and add it to the appointments ArrayList
                    Booking booking = new Booking(firstName, lastName, phoneNumber, emailAddress,
                            checkInDate, checkOutDate, roomCapacity, uniqueID);
                    ApplicationController.appointments.add(booking);
                }
            }

            // Store current appointment information
            Booking currentAppointmentInformation;

            // Remove last row in the appointments ArrayList which is all null
            ApplicationController.appointments.remove(ApplicationController.appointments.size() - 1);

            // Search through all appointments and match the current ID to appointments with the same ID
            // Add current appointment information to the current appointment ArrayList
            for (int index = 0; index < ApplicationController.appointments.size(); index++) {
                if (ApplicationController.appointments.get(index).getUniqueID().equals(ApplicationController.currentID)) {
                    currentAppointmentInformation = ApplicationController.appointments.get(index);
                    ApplicationController.currentAppointments.add(currentAppointmentInformation);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getElementTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        } else {
            return "";
        }
    }
}

