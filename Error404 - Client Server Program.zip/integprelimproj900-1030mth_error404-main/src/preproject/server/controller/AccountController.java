package preproject.server.controller;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import preproject.server.model.Account;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

public class AccountController {

    private static AccountController instance;

    public void importAccounts(String fileName) {
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                System.out.println("File not found: " + fileName);
                return;
            }

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file);
            doc.getDocumentElement().normalize();

            NodeList nodeList = doc.getElementsByTagName("account");

            // For all account elements in the XML
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);

                // Attempt to get account information from XML elements
                try {
                    String firstName = getElementTextContent(element, "firstName");
                    String lastName = getElementTextContent(element, "lastName");
                    String age = getElementTextContent(element, "age");
                    String phoneNumber = getElementTextContent(element, "phoneNumber");
                    String email = getElementTextContent(element, "email");
                    String password = getElementTextContent(element, "password");
                    boolean isAdmin = Boolean.parseBoolean(getElementTextContent(element, "isAdmin"));
                    boolean isBanned = Boolean.parseBoolean(getElementTextContent(element, "isBanned"));
                    boolean isOnline = Boolean.parseBoolean(getElementTextContent(element, "isOnline"));
                    boolean isDelete = Boolean.parseBoolean(getElementTextContent(element, "isDelete"));
                    String uniqueID = getElementTextContent(element, "uniqueID");

                    // Add information to accounts ArrayList
                    if (areAllNonNull(firstName, lastName, age, phoneNumber, email, password, uniqueID)) {
                        ApplicationController.accounts.add(new Account(firstName, lastName, age, phoneNumber,
                                email, password, isAdmin, isBanned, isOnline, isDelete, uniqueID));
                    } else {
                        // Handle the case where one or more essential elements are missing
                        System.out.println("Error processing account entry at index " + i + ". Skipping.");
                    }
                } catch (NullPointerException e) {
                    // Handle the case where one or more elements are missing
                    System.out.println("Error processing account entry at index " + i + ". Skipping.");
                    e.printStackTrace();
                }
            }

        } catch (ParserConfigurationException | IOException e) {
            e.printStackTrace();
        } catch (org.xml.sax.SAXException e) {
            e.printStackTrace();
        }
    }

    private String getElementTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        return (nodeList.getLength() > 0 && nodeList.item(0) != null) ? nodeList.item(0).getTextContent() : null;
    }

    private boolean areAllNonNull(String... values) {
        for (String value : values) {
            if (value == null) {
                return false;
            }
        }
        return true;
    }

    public void loadOnlineAccounts(String fileName) {
        // Clear the existing onlineAccounts list
        ApplicationController.onlineAccounts.clear();
    
        String filePath = fileName;
        File xmlFile = new File(filePath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
    
            // parse xml file and load into document
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
    
            // loop for each user
            for (int i = 0; i < ApplicationController.accounts.size(); i++) {
                Account account = ApplicationController.accounts.get(i);
    
                // Fields to get input values
                String firstName = account.getFirstName();
                String lastName = account.getLastName();
                String age = account.getAge();
                String phoneNumber = account.getPhoneNumber();
                String email = account.getEmail();
                String password = account.getPassword();
                boolean isAdmin = account.isAdmin();
                boolean isBanned = account.isBanned();
                boolean isOnline = isAccountOnline(email); // Check if the account is online
                boolean isDelete = account.isDelete();
                String uniqueID = account.getUUID();
    
                // Add information to onlineAccounts ArrayList
                ApplicationController.onlineAccounts.add(new Account(firstName, lastName, age, phoneNumber, email, password, isAdmin, isBanned, isOnline, isDelete, uniqueID));
            }
    
            doc.getDocumentElement().normalize();
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("accounts/online.xml"));
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
            System.out.println("XML file updated successfully");
    
        } catch (SAXException | ParserConfigurationException | IOException | TransformerException e1) {
            e1.printStackTrace();
        }
    
        updateOnlineStatus();
    }
    
    //  To check if an account is online
    private boolean isAccountOnline(String email) {
        for (Account onlineAccount : ApplicationController.onlineAccounts) {
            if (onlineAccount.getEmail().equals(email) && !onlineAccount.isBanned()) {
                return true;
            }
        }
        return false;
    }


    public void updateOnlineStatus() {
        for (Account onlineAccount : ApplicationController.onlineAccounts) {
            boolean newOnlineStatus = isAccountOnline(onlineAccount.getEmail());
            onlineAccount.setOnline(newOnlineStatus);
        }
    }
    
    public void loadDeleteAccounts(String fileName) {
        // implementation here
    }

}

