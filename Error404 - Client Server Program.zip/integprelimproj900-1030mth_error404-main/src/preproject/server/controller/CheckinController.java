package preproject.client.controller;


import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import preproject.client.view.RegisterScreen;
import preproject.client.view.ScreenType;
import preproject.client.view.BookingHistoryScreen;
import preproject.client.view.CheckinScreen;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class CheckinController implements ActionListener{
    private CheckinScreen checkinScreen; // Access booking screen
    private ApplicationController applicationController;

    public CheckinController(CheckinScreen checkinScreen, ApplicationController applicationController) {
        this.checkinScreen = checkinScreen;
        this.applicationController = applicationController;
    }

    public void run(){
        setUpListeners();
        applicationController.switchScreen(checkinScreen);
    }

    private void setUpListeners() {
        checkinScreen.getSubmitButton().addActionListener(this);
        checkinScreen.getClearButton().addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
        if (e.getSource() == checkinScreen.getSubmitButton()) {
            submit();
        } else if (e.getSource() == checkinScreen.getClearButton()) {
            clear();
        }
    }

    private void submit() {
        String firstName = checkinScreen.getFirstNameField().getText();
        String lastName = checkinScreen.getLastNameField().getText();
        String phone = checkinScreen.getPhoneField().getText();
        String email = checkinScreen.getEmailField().getText();

        // Check if all fields are filled out
        if (!firstName.isEmpty() && !lastName.isEmpty() && !phone.isEmpty() && !email.isEmpty()) {
            // Your booking submission logic goes here
            // For demonstration purposes, let's call the success method in CheckinScreen
            checkinScreen.displaySuccessMessage("Successfully booked!");
        } else {
            // Display an error message if any field is empty
            checkinScreen.displayErrorMessage("Please fill out all fields.");
        }
    }



    private void clear(){
        checkinScreen.getFirstNameField().setText(null);
        checkinScreen.getLastNameField().setText(null);
        checkinScreen.getPhoneField().setText(null);
        checkinScreen.getEmailField().setText(null);
        checkinScreen.getCheckInYearComboBox().setSelectedItem("Year");
        checkinScreen.getCheckInMonthComboBox().setSelectedItem("Month");
        checkinScreen.getCheckInDayComboBox().setSelectedItem("Day");
        checkinScreen.getCheckOutYearComboBox().setSelectedItem("Year");
        checkinScreen.getCheckOutMonthComboBox().setSelectedItem("Month");
        checkinScreen.getCheckOutDayComboBox().setSelectedItem("Day");
        checkinScreen.getRoomCapacityComboBox().setSelectedItem("Choose Room Capacity");
    }
}

    
