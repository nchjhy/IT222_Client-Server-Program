package preproject.server.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import preproject.server.view.CheckoutScreen;

 public class CheckoutController implements ActionListener {
    
        private CheckoutScreen checkoutScreen;
    
        public CheckoutController(CheckoutScreen checkoutScreen) {
            this.checkoutScreen = checkoutScreen;
    
            // Attach ActionListener to the check-out button
            checkoutScreen.getCheckouButton().addActionListener(this);
            // Attach ActionListener to the clear button
            checkoutScreen.getClearButton().addActionListener(this);
        }
    
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == checkoutScreen.getCheckouButton()) {
                performCheckOut();
            } else if (e.getSource() == checkoutScreen.getClearButton()) {
                clearFields();
            }
            // Add other actions if needed
        }
    
        private void performCheckOut() {
            // Implement check-out logic
            // You can access the room number using checkoutScreen.getRoomNo()
            // Show a message or perform necessary operations
            JOptionPane.showMessageDialog(checkoutScreen, "Check-out Successful");
        }
    
        private void clearFields() {
            checkoutScreen.clearFields();
        }
    }
    