package preproject.server.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

import preproject.server.Server;
import preproject.server.model.ScreenType;
import preproject.server.view.AnnouncementScreen;

public class AnnouncementController implements ActionListener, DocumentListener {

    public AnnouncementScreen announcementScreen;
    private ObjectOutputStream serverStream;

    public AnnouncementController(AnnouncementScreen announcementScreen) {
        this.announcementScreen = announcementScreen;
        setupListeners();
    }
    public AnnouncementController(AnnouncementScreen announcementScreen, ObjectOutputStream serverStream) {
        this.announcementScreen = announcementScreen;
        this.serverStream = serverStream;
        setupListeners();
    }

    private void setupListeners() {
        announcementScreen.getAnnouceButton().addActionListener(this);
        Document document = announcementScreen.getAnnoucementArea().getDocument();
        document.addDocumentListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == announcementScreen.getAnnouceButton()) {
            // serverStream.writeObject("Announcement: " + announcementScreen.getAnnoucementArea().getText());
            String announcement = announcementScreen.getAnnoucementArea().getText();
      
            // Send the announcement to all connected clients
            sendAnnouncementToAllClients(announcement);
        }
            
        }
        private void sendAnnouncementToAllClients(String announcement) {
    for (Map.Entry<Integer, ObjectOutputStream> entry : Server.clientOutputs.entrySet()) {
        Integer clientId = entry.getKey();
        ObjectOutputStream clientStream = entry.getValue();
        
        try {
            clientStream.writeObject(announcement);
            clientStream.flush();
            
            System.out.println("Announcement sent to client: " + clientId);
        } catch (IOException e) {
            // Handle the exception (e.g., remove disconnected client from the map)
            e.printStackTrace();
            System.err.println("Error sending announcement to client: " + clientId);
        }
    }
}


    @Override
    public void insertUpdate(DocumentEvent e) {
        // Handle insert (text added to the document)
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        // Handle remove (text removed from the document)
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        // Handle change (attributes of the document changed)
    }
}


