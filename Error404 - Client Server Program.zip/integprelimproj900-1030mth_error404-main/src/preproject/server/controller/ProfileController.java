package preproject.server.controller;

import preproject.server.view.ProfileScreen;

public class ProfileController {

    private ProfileScreen profileScreen; // Access ProfileScreen

    // Constructor
    public ProfileController(ProfileScreen profileScreen) {
        this.profileScreen = profileScreen;
    }

    // Profile labels with user data
    public void setupLabel() {
        profileScreen.getNameLabel().setText("Name: " + ApplicationController.currentFirstName +
                " " + ApplicationController.currentLastName);
        // profileScreen.getAgeLabel().setText("Age: " + ApplicationController.currentAge);
        profileScreen.getPhoneNumberLabel().setText("Phone Number: " + ApplicationController.currentPhoneNumber);
        profileScreen.getEmailLabel().setText("Email: " + ApplicationController.currentEmail);
        
    }
}
