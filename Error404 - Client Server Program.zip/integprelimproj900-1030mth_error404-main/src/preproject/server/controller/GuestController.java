package preproject.server.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import preproject.server.model.Account;
import preproject.server.view.GuestScreen;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class GuestController implements ActionListener {
    private GuestScreen guestScreen;
    private DefaultTableModel tableModel;

    public GuestController(GuestScreen guestScreen) {
        this.guestScreen = guestScreen;
        this.tableModel = (DefaultTableModel) guestScreen.getTable().getModel();

        // Attach ActionListener to the search button
        guestScreen.addSearchButtonListener(this);
        // Initialize the table with all registered accounts
        updateTable(ApplicationController.accounts);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == guestScreen.getSearchButton()) {
            // Perform search based on the entered keyword
            String keyword = guestScreen.getSearchKeyword();
            searchByEmail(keyword);
        }
    }

    private void searchByEmail(String emailKeyword) {
        // Clear existing rows in the table
        tableModel.setRowCount(0);

        if (!emailKeyword.isEmpty()) {
            for (Account account : ApplicationController.accounts) {
                if (account.getEmail().contains(emailKeyword)) {
                    Object[] rowData = {
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmail(),
                            account.isAdmin(),
                            account.isBanned() ? "Banned" : "Not Banned"
                    };
                    tableModel.addRow(rowData);
                }
            }
        } else {
            // If the search keyword is empty, refresh the table with the original list
            updateTable(ApplicationController.accounts);
        }
    }

    private void updateTable(List<Account> accounts) {
        // Update the table with the provided accounts
        for (Account account : accounts) {
            Object[] rowData = {
                    account.getFirstName(),
                    account.getLastName(),
                    account.getAge(),
                    account.getPhoneNumber(),
                    account.getEmail(),
                    account.isBanned() ? "Banned" : "Not Banned"
            };
            tableModel.addRow(rowData);
        }
    }
}
