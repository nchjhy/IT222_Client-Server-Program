package preproject.server.model;

public class Account {

    // Fields
    private String firstName;
    private String lastName;
    private String age;
    private String phoneNumber;
    private String email;
    private String password;
    private boolean isAdmin;
    private boolean isBanned;
    private boolean isOnline;
    private boolean isDelete;
    private String UUID;

    // Constructor
    public Account(String firstName, String lastName, String age, String phoneNumber, String email, String password, String UUID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = false;
        this.isBanned = false;
        this.isOnline = false;
        this.isDelete = false;
        this.UUID = UUID;
    }

    public Account(String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, String UUID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = false;
        this.isOnline = false;
        this.isDelete = false;
        this.UUID = UUID;
    }

    public Account(String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, boolean isBanned, String UUID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = isBanned;
        this.isOnline = false;
        this.isDelete = false;
        this.UUID = UUID;
    }

    public Account(String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, boolean isBanned, boolean isOnline, String UUID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = isBanned;
        this.isOnline = isOnline;
        this.isDelete = false;
        this.UUID = UUID;
    }

    public Account(String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, boolean isBanned, boolean isOnline, boolean isDelete, String UUID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = isBanned;
        this.isOnline = isOnline;
        this.isDelete = isDelete;
        this.UUID = UUID;
    
    }

    // Getters & Setters
    public String getFirstName() { 
        return firstName; 
    }

    public String getLastName() {
        return lastName;
    }

    public String getAge() {
        return age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public boolean isBanned() {
        return isBanned;
    }

    public boolean isOnline() {
        return isOnline;
    }

    public boolean isDelete() {
        return isDelete;
    }

    public String getUUID() { return UUID; }

    public void setAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public void setBanned(boolean isBanned) {
        this.isBanned = isBanned;
    }

    public void setOnline(boolean isOnline) {
        this.isOnline = isOnline;
    }

    public void setDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setUUID(String uUID) {
        UUID = uUID;
    }

    // toString method
    @Override
    public String toString() {
        return firstName + ", " + lastName + ", " +  age + ", " + phoneNumber + ", " + email + ", " + password + ", " + isAdmin + ", " + isBanned + ", " + UUID;
    }
}
