package preproject.server.model;

import java.io.File;

import org.w3c.dom.*;

import preproject.server.model.Account;
import preproject.server.model.Booking;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

public class XMLProcessor {
    /** Method for creating an XML file 
     * @param filePath: The path where you want to create your XML file
     * @param  rootElementName: The name of the root element of your XML document
    */
    private void createXML(String filePath, String rootElementName) throws Exception{
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document document = dBuilder.newDocument();

            Element rootElement = document.createElement(rootElementName);
            document.appendChild(rootElement);

            cleanDocument(document);

            saveXML(document, filePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Method for saving the XML file when creating or updating it
     * @param document
     * @param filePath
     * @return true/false
     */
    public boolean saveXML(Document document, String filePath) {
        try {
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(new File(filePath));

            synchronized (transformer) { //ensures that if multiple threads attempt to execute this block of code concurrently, they will be forced to wait their turn
                transformer.transform(source, result);
                cleanDocument(document);
            } return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Method for reading information from an existing XML file into memory as objects that can be used by other methods
     * @param  filePath: The location of the XML file you wish to read from
     * @return document built from XML file
    */
    public synchronized Document readXML(String filePath) throws Exception {
        Document document = null;

        File file  = new File(filePath);
        if (!file.exists()) { // If the file does not exist, create the XML file
            createXML(filePath, "accounts");
        }
        // if file exists, parse it with this try-catch block
        try {
            DocumentBuilder docBuilder = DocumentBuilderFactory.newDefaultInstance().newDocumentBuilder();
            document = docBuilder.parse(filePath);
            document.getDocumentElement().normalize();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } return document;
    } 
    /**Method to add an Account to an XML file */
    private boolean addAccountToXML(String filePath, Account account) throws Exception {
        Document document = readXML(filePath);

        if (document != null) {
            Element rootElement = document.getDocumentElement();

            Element newAccountNode = document.createElement("accounts");

            newAccountNode.setAttribute("firstName", account.getFirstName());
            newAccountNode.setAttribute("lastName", account.getLastName());
            newAccountNode.setAttribute("age", account.getAge());
            newAccountNode.setAttribute("phoneNumber", account.getPhoneNumber());
            newAccountNode.setAttribute("email", account.getEmail());
            newAccountNode.setAttribute("password", account.getPassword());
            newAccountNode.setAttribute("isAdmin", String.valueOf(account.isAdmin()));
            newAccountNode.setAttribute("isBanned", "false");
            newAccountNode.setAttribute("isOnline", String.valueOf(account.isOnline()));
            newAccountNode.setAttribute("isDelete", String.valueOf(account.isDelete())); 
            newAccountNode.setAttribute("username", account.getUUID());

            rootElement.appendChild(newAccountNode);

            return saveXML(document, filePath);
        }
        return false;
    }
    /**Method to remove an Account from an XML file 
     * @throws Exception */
    
     private boolean removeAccountFromXML(String filePath, String username) throws Exception {
        Document document = readXML(filePath);
    
        NodeList nodes = document.getElementsByTagName("account");
    
        if (document != null) {
            for (int i = 0; i < nodes.getLength(); i++) {
                Node currentNode = nodes.item(i);
                String userID = currentNode.getAttributes().getNamedItem("username").getNodeValue();
                boolean isDelete = Boolean.parseBoolean(currentNode.getAttributes().getNamedItem("isDelete").getNodeValue());
    
                if (userID.equalsIgnoreCase(username) && !isDelete) { // Check isDelete flag
                    document.getElementsByTagName("accounts").item(0).removeChild(currentNode);
                    return saveXML(document, filePath);
                }
            }

            cleanDocument(document);
        }
        return false;
    }
    
    /**
     * Cleans the provided XML document by removing empty text nodes.
     * @param document the document to be cleaned
     * @throws XPathExpressionException occurs if there is an error during node evaluation
     */
    public static void cleanDocument(Document document) throws XPathExpressionException {
        XPathFactory xPathFactory = XPathFactory.newInstance();

        XPathExpression xPathExpression = xPathFactory
                .newXPath()
                .compile("//text()[normalize-space(.) = '']");

        NodeList emptyTextNodes = (NodeList) xPathExpression
                .evaluate(document, XPathConstants.NODESET);

        for (int i = 0; i < emptyTextNodes.getLength(); i++) {
            Node emptyTextNode = emptyTextNodes.item(i);
            emptyTextNode.getParentNode().removeChild(emptyTextNode);
        }
    } // end of cleanDocument
}

