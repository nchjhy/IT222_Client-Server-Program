package preproject.server.model;

public enum ScreenType {

    // Values for each screen
    LOGIN_SCREEN(0),
    REGISTER_SCREEN(1),
    ADMINHOME_SCREEN(2),
    CLIENTHOME_SCREEN(3),
    CHECKIN_SCREEN(4),
    VIEW_APPOINTMENTS_SCREEN(5),
    PROFILE_SCREEN(6),
    ANNOUNCEMENT_SCREEN(7),
    GUEST_SCREEN(8),
    CHECKOUT_SCREEN(9),
    CANCELBOOKING_SCREEN(10),
    BOOKINGHISTORY_SCREEN(11),
    CLIENTBOOKINGHISTORY_SCREEN(12),
    USER_SCREEN(13); 

    private int value; // Value of screen

    // Constructor
    ScreenType(int value) { this.value = value; }

    // Getter
    public int getValue() { return value; }

}
