package preproject.server.model;

public class Booking {

    // Fields
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;
    private String check_in_date;
    private String check_out_date;
    private String roomCapacity;
    private String uniqueID;

    // Constructor
    public Booking(String firstName, String lastName, String phoneNumber, String emailAddress,
                   String check_in_date, String check_out_date, String roomCapacity, String uniqueID) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.check_in_date = check_in_date;
        this.check_out_date = check_out_date;
        this.roomCapacity = roomCapacity;
        this.uniqueID = uniqueID;
    }

    // Getters
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getCheck_in_date() {
        return check_in_date;
    }

    public String getCheck_out_date() {
        return check_out_date;
    }

    public String getRoomCapacity() {
        return roomCapacity;
    }

    public String getUniqueID() { 
        return uniqueID; 
    }

    // Getting only relevant data for the appointment (all null is ignored)
    private String getAppointment() {
        String appointments = "";

        if (!this.firstName.contains("null")) {
            appointments += "Booking Details: " + this.firstName + ", ";
        }
        if (!this.lastName.contains("null")) {
            appointments += this.lastName + ", ";
        }
        if (!this.phoneNumber.contains("null")) {
            appointments += this.phoneNumber + ", ";
        }
        if (!this.emailAddress.contains("null")) {
            appointments += this.emailAddress + ", ";
        }
        if (!this.check_in_date.contains("null")) {
            appointments += this.check_in_date + ", ";
        }
        if (!this.check_out_date.contains("null")) {
            appointments += this.check_out_date + ", ";
        }
        if (!this.roomCapacity.contains("null")){
            appointments += this.roomCapacity + ", ";
        }
        if (!this.uniqueID.contains("null")) {
            appointments += this.uniqueID;
        }
        return appointments;
    }

    // toString method
    @Override
    public String toString() {
        String appointments = getAppointment();
        return appointments;
    }
}
