package preproject.server;

import java.io.*; //For input/output operations
import java.net.*; //For network operations
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Server class 
public class Server {
    //List of output streams for all connected clients
    public static final ConcurrentHashMap<Integer, ObjectOutputStream> clientOutputs = new ConcurrentHashMap<>();
    private static int clientNum = 1;
    private static final int BROADCAST_PORT = 12345;

    public static void main(String[] args) {
        run();
    }

    //Starts the server and listens for incoming client connections
    public static void run() {
        
        System.out.println("Server is running...");
        //Server socket to listen for client connections
        try (ServerSocket serverSocket = new ServerSocket(1234)) {
            // server is listening on port 1234
            startBroadcastingServer();

            // running infinite loop for getting client request
            while (true) {
                // socket object to receive incoming client requests
                Socket clientSocket = serverSocket.accept();

                // display that new client is connected to server
                System.out.println("New client connected: " + clientSocket.getInetAddress().getHostAddress());

                // create a new output stream for the client
                ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                out.flush();
                clientOutputs.put(clientNum, out);

                // client handler instance to handle the client requests
                ClientHandler clientHandler = new ClientHandler(clientSocket, clientNum);
                // create a new thread object
                // this thread will handle the client separately
                new Thread(clientHandler).start();
                clientNum++;
            }
        } catch (IOException e) {
            e.printStackTrace(); }
        // } finally {
        //     if (serverSocket != null) {
        //         try {
        //             serverSocket.close();
        //         } catch (IOException e) {
        //             e.printStackTrace();
        //         }
        //     }
        // }
    }

    /** Starts broadcasting the server's presence to all machines connected to the local network */
    private static void startBroadcastingServer() {
        new Thread(() -> {
            try (DatagramSocket broadcastSocket = new DatagramSocket(BROADCAST_PORT)) {
                System.out.println("Server broadcasting its presence on port " + BROADCAST_PORT);

                while (true) {
                    byte[] receiveData = new byte[1024];
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    broadcastSocket.receive(receivePacket);
                    System.out.println("Connection request received from: " + receivePacket.getAddress());

                    String serverIP = InetAddress.getLocalHost().getHostAddress();
                    byte[] sendData = serverIP.getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, receivePacket.getAddress(), receivePacket.getPort());
                    broadcastSocket.send(sendPacket);
                }
            } catch (IOException e) {
                System.err.println("Error during broadcast startup: " + e.getMessage());
            }
        }).start();
    } // end of startBroadcastingServer

    //ClientHandler class
    private static class ClientHandler implements Runnable {
        private final Socket clientSocket; //Client socket
        private final int clientNum; //Output stream for the client

        //Constructor
        public ClientHandler(Socket socket, int clientNum) {
            this.clientSocket = socket;
            this.clientNum = clientNum;
        }

        @Override
        public void run() {
            try (ObjectOutputStream out = clientOutputs.get(clientNum);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
                
                while (true) {
                    String line = in.readLine();
                    if (line == null) {
                        break;
                    }
                    broadcast(line);
                }
            } catch (IOException e) {
                // Client disconnected
                System.out.println("Client disconnected: " + clientSocket.getInetAddress().getHostAddress());
                clientOutputs.remove(clientNum);
            }
        }

        private void broadcast(String message) {
            for (ObjectOutputStream stream : clientOutputs.values()) {
                try {
                    stream.writeObject(message);
                    stream.flush();
                } catch (IOException e) {
                    // Error broadcasting message to a client
                    System.err.println("Error broadcasting message: " + e.getMessage());
                }
            }
        }
    }
}
