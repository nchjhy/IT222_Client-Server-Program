package preproject.server.view;

import javax.swing.*;
import java.awt.*;

public class RegisterScreen extends Screen {

    // Fields
    private JLabel registerTitleLabel = new JLabel(new ImageIcon("src/preproject/utilities/pictures/registerTitle.png"));
    private JTextField firstNameField = new JTextField();
    private JTextField lastNameField = new JTextField();
    private JTextField ageField = new JTextField();
    private JTextField phoneNumberField = new JTextField();
    private JTextField emailField = new JTextField();
    private JPasswordField passwordField = new JPasswordField();
    private JPasswordField confirmPasswordField = new JPasswordField();
    
    

    private JLabel firstNameLabel = new JLabel("First Name");
    private JLabel lastNameLabel = new JLabel("Last Name");
    private JLabel ageLabel = new JLabel("Age");
    private JLabel phoneNumberLabel = new JLabel("Phone Number");
    private JLabel emailLabel = new JLabel("Email");
    private JLabel passwordLabel = new JLabel("Password");
    private JLabel confirmPasswordLabel = new JLabel("Confirm Password");

    private JCheckBox showPassword = new JCheckBox("Show password");

    private JButton signUpButton = new JButton("SIGN UP");

    private static final Font FONT = new Font("Tahoma", Font.PLAIN, 16);
    private static final Color COLOUR = new Color(128, 128, 128);

    public RegisterScreen() {

        setBackground(new Color(211, 211, 211));

        // Title
        registerTitleLabel.setBounds(0, 0, 1600, 900);
        add(registerTitleLabel);

        // First Name Field
        firstNameField.setForeground(COLOUR);
        firstNameField.setBounds(525, 228, 254, 33);
        add(firstNameField);
        firstNameField.setColumns(10);

        // Last Name Field
        lastNameField.setForeground(COLOUR);
        lastNameField.setColumns(10);
        lastNameField.setBounds(825, 228, 249, 33);
        add(lastNameField);

        // Age Field
        ageField.setForeground(COLOUR);
        ageField.setColumns(10);
        ageField.setBounds(525, 305, 254, 33);
        add(ageField);

        // Phone Number Field
        phoneNumberField.setForeground(COLOUR);
        phoneNumberField.setColumns(10);
        phoneNumberField.setBounds(825, 305, 249, 33);
        add(phoneNumberField);

        // Email Field
        emailField.setForeground(COLOUR);
        emailField.setBounds(525, 390, 550, 33);
        emailField.setColumns(10);
        add(emailField);

        // Password Field
        passwordField.setForeground(COLOUR);
        passwordField.setColumns(10);
        passwordField.setBounds(525, 480, 254, 33);
        add(passwordField);

        // Confirm Password Field
        confirmPasswordField.setForeground(COLOUR);
        confirmPasswordField.setColumns(10);
        confirmPasswordField.setBounds(825, 480, 247, 33);
        add(confirmPasswordField);

        // First Name Label
        firstNameLabel.setFont(FONT);
        firstNameLabel.setBounds(525, 197, 100, 20);
        add(firstNameLabel);

        // Last name label
        lastNameLabel.setFont(FONT);
        lastNameLabel.setBounds(825, 197, 100, 20);
        add(lastNameLabel);

        // Age label
        ageLabel.setFont(FONT);
        ageLabel.setBounds(525, 280, 100, 20);
        add(ageLabel);

        // Phone number label
        phoneNumberLabel.setFont(FONT);
        phoneNumberLabel.setBounds(825, 280, 114, 14);
        add(phoneNumberLabel);

        // Email label
        emailLabel.setFont(FONT);
        emailLabel.setBounds(525, 369, 127, 14);
        add(emailLabel);

        // Password label
        passwordLabel.setFont(FONT);
        passwordLabel.setBounds(525, 456, 101, 14);
        add(passwordLabel);

        // Confirm password label
        confirmPasswordLabel.setFont(FONT);
        confirmPasswordLabel.setBounds(825, 456, 153, 14);
        add(confirmPasswordLabel);

        // Show password checkbox
        showPassword.setBackground(new Color(211, 211, 211));
        showPassword.setBounds(525, 515, 129, 23);
        add(showPassword);

        // Sign up button
        signUpButton.setBackground(new Color(100, 149, 237));
        signUpButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
        signUpButton.setBounds(690, 550, 210, 50);
        add(signUpButton);
    }

    public JTextField getFirstNameField() { return firstNameField; }

    public JTextField getLastNameField() { return lastNameField; }

    public JTextField getAgeField() { return ageField; }

    public JTextField getPhoneNumberField() { return phoneNumberField; }
    
    public JTextField getEmailField() { return emailField; }

    public JPasswordField getPasswordField() { return passwordField; }

    public JPasswordField getConfirmPasswordField() { return confirmPasswordField; }

    public JCheckBox getShowPassword() { return showPassword; }

    public JButton getSignUpButton() { return signUpButton; }
}
