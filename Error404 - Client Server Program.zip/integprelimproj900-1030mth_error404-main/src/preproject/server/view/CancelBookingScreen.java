package preproject.server.view;

import javax.swing.*;
import java.awt.*;

public class CancelBookingScreen extends Screen {
    private JTextField emailField, firstNameField, lastNameField;
    private JButton clearButton, cancelBookingButton;

    public CancelBookingScreen() {
        initializeComponents();
        setLayout(new BorderLayout());
        getBackButton().setVisible(false);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel titleLabel = new JLabel("CANCEL BOOKING");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(590, 70, 500, 50);
        mainPanel.add(titleLabel);

        JLabel firstNameLabel = new JLabel("First Name: ");
        firstNameLabel.setFont(new Font("Arial", Font.BOLD, 20));
        firstNameLabel.setBounds(620, 260, 200, 65);
        firstNameField.setBounds(750, 260, 200, 40);

        JLabel lastNameLabel = new JLabel("Last Name: ");
        lastNameLabel.setFont(new Font("Arial", Font.BOLD, 20));
        lastNameLabel.setBounds(620, 330, 200, 45);
        lastNameField.setBounds(750, 330, 200, 40);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 20));
        emailLabel.setBounds(620, 390, 200, 45);
        emailField.setBounds(750, 390, 200, 40);

        clearButton.setBounds(680, 500, 90, 40);
        clearButton.setBackground(new Color(192, 192, 192));
        clearButton.setFont(new Font("Tahoma", Font.BOLD, 12));

        cancelBookingButton.setBounds(830, 500, 130, 40);
        cancelBookingButton.setBackground(new Color(205, 92, 92));
        cancelBookingButton.setFont(new Font("Tahoma", Font.BOLD, 12));


        mainPanel.add(firstNameLabel);
        mainPanel.add(firstNameField);
        mainPanel.add(lastNameLabel);
        mainPanel.add(lastNameField);
        mainPanel.add(emailLabel);
        mainPanel.add(emailField);
        mainPanel.add(clearButton);
        mainPanel.add(cancelBookingButton);

        add(mainPanel);
    }

    private void initializeComponents() {
        firstNameField = new JTextField();
        lastNameField = new JTextField();
        emailField = new JTextField();

        clearButton = new JButton("Clear");
        cancelBookingButton = new JButton("Cancel Booking");
    
    }

    public String getEmail() {
        return emailField.getText();
    }

    public String getFirstName() {
        return firstNameField.getText();
    }

    public String getLastName() {
        return lastNameField.getText();
    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JButton getCancelBookingButton() {
        return cancelBookingButton;
    }

    public void clearFields() {
        emailField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
    }
}
