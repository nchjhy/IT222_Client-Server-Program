package preproject.server.view;

import javax.swing.*;

import java.awt.*;

public class AdminHomeScreen extends Screen {
    private JLabel welcomeLabel = new JLabel("Welcome to Error 404 Trancients");
    private JButton appointmentButton = new JButton("Booking", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/check-in.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton viewAppointmentButton = new JButton("<html>View previous<br/>Bookings</html>", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/room.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton profileButton = new JButton("Your Profile", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/user.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton annoucementButton = new JButton("Announcement", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/announce.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton guestButton = new JButton("Guest", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/guest.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT)));
    private JButton bookingHistoryButton = new JButton("<html>Booking<br/>History</html>", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/bhistory.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton logoutButton = new JButton("Logout", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/logout.png").getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT)));
    private JButton userButton = new JButton("<html>Accounts<br/>Registered<html>", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/users.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));

    private static final Font FONT = new Font("Tahoma", Font.PLAIN, 30);

    public AdminHomeScreen() {
        getBackToHomeButton().setVisible(false);
        setBackground(new Color(113, 146, 172));

        welcomeLabel.setBounds(70, 50, 1000, 100);
        welcomeLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        welcomeLabel.setForeground(Color.WHITE);
        add(welcomeLabel);

        appointmentButton.setBackground(new Color(30, 75, 135));
        appointmentButton.setForeground(Color.WHITE);
        appointmentButton.setFont(FONT);
        appointmentButton.setBorder(null);
        appointmentButton.setBounds(300, 350, 255, 125);
        add(appointmentButton);

        viewAppointmentButton.setBackground(new Color(30, 75, 135));
        viewAppointmentButton.setForeground(Color.WHITE);
        viewAppointmentButton.setFont(FONT);
        viewAppointmentButton.setBorder(null);
        viewAppointmentButton.setBounds(700, 350, 255, 125);
        add(viewAppointmentButton);

        userButton.setBackground(new Color(30, 75, 135));
        userButton.setForeground(Color.WHITE);
        userButton.setFont(FONT);
        userButton.setBorder(null);
        userButton.setBounds(1100, 150, 255, 125);
        add(userButton);

        profileButton.setBackground(new Color(30, 75, 135));
        profileButton.setForeground(Color.WHITE);
        profileButton.setFont(FONT);
        profileButton.setBorder(null);
        profileButton.setBounds(700, 550, 255, 125);
        add(profileButton);

        bookingHistoryButton.setBackground(new Color(30, 75, 135));
        bookingHistoryButton.setForeground(Color.WHITE);
        bookingHistoryButton.setFont(FONT);
        bookingHistoryButton.setBorder(null);
        bookingHistoryButton.setBounds(1100, 350, 255, 125);
        add(bookingHistoryButton);

        annoucementButton.setBackground(new Color(30, 75, 135));
        annoucementButton.setForeground(Color.WHITE);
        annoucementButton.setFont(FONT);
        annoucementButton.setBorder(null);
        annoucementButton.setBounds(300, 150, 255, 125); 
        add(annoucementButton);

        guestButton.setBackground(new Color(30, 75, 135));
        guestButton.setForeground(Color.WHITE);
        guestButton.setFont(FONT);
        guestButton.setBorder(null);
        guestButton.setBounds(700, 150, 255, 125);
        add(guestButton);

        logoutButton.setBackground(new Color(30, 75, 135));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Tahoma", Font.BOLD, 20));
        logoutButton.setBorder(null);
        logoutButton.setBackground(new Color(205, 92, 92));
        logoutButton.setBounds(750, 750, 150, 50);
        add(logoutButton);



    }

    public JLabel getWelcomeLabel() { return welcomeLabel; }

    public JButton getAppointmentButton() { return appointmentButton; }

    public JButton getViewAppointmentButton() { return viewAppointmentButton; }

    public JButton getProfileButton() { return profileButton; }

    public JButton getBookingHistoryButton() { return bookingHistoryButton; }

    public JButton getAnnouncementButton() { return annoucementButton; }

    public JButton getGuestButton() { return guestButton; }

    public JButton getLogoutButton(){ return logoutButton; }

    public JButton getUserButton(){ return userButton; }


}
