package preproject.client.view;

import javax.swing.*;
import java.awt.*;

public class CheckinScreen extends Screen {
    private JTextField firstNameField, lastNameField, phoneField, emailField;
    private JButton submitButton, clearButton;
    private JComboBox<String> checkInYearComboBox, checkInMonthComboBox, checkInDayComboBox,
            checkoutYearComboBox, checkoutMonthComboBox, checkoutDayComboBox;
    private JComboBox<String> roomCapacityComboBox;

    public CheckinScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
//        setLayout(null);
//        getBackButton().setVisible(true);
//        setBackground(new Color(113, 146, 172));
//
//        // Title Label
//        JLabel titleLabel = new JLabel("BOOKING");
//        titleLabel.setBounds(680, 70, 500, 50);
//        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
//        titleLabel.setForeground(Color.WHITE);
//        add(titleLabel);
//
//        // Personal Data Panel
//        addLabelAndField("First Name:", firstNameField, 300, 200);
//        addLabelAndField("Last Name:", lastNameField, 300, 280);
//        addLabelAndField("Phone:", phoneField, 300, 360);
//        addLabelAndField("Email:", emailField, 300, 440);
//
//        // Room Data Panel
//        addLabelAndField("Check-In Date:", dateComboBoxPanel(checkInYearComboBox, checkInMonthComboBox, checkInDayComboBox), 900, 200);
//        addLabelAndField("Check-Out Date:", dateComboBoxPanel(checkoutYearComboBox, checkoutMonthComboBox, checkoutDayComboBox), 900, 280);
//        addLabelAndField("Room Capacity:", roomCapacityComboBox, 900, 350);
//
//        // Button Panel
//        submitButton.setBounds(650, 550, 100, 40);
//        submitButton.setBackground(new Color(143, 188, 143));
//        submitButton.setFont((new Font("Submit",Font.BOLD,15)));
//        add(submitButton);
//
//        clearButton.setBounds(855, 550, 100, 40);
//        clearButton.setBackground(new Color(192, 192, 192));
//        clearButton.setFont((new Font("Clear",Font.BOLD,15)));
//        add(clearButton);

    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
//        firstNameField = createTextField();
//        lastNameField = createTextField();
//        phoneField = createTextField();
//        emailField = createTextField();
//        submitButton = new JButton("Submit");
//        clearButton = new JButton("Clear");
//        roomCapacityComboBox = new JComboBox<>(getRoomCapacityOptions());
//
//        // Dropdown dates
//        checkInYearComboBox = new JComboBox<>(getYearOptions());
//        checkInMonthComboBox = new JComboBox<>(getMonthOptions());
//        checkInDayComboBox = new JComboBox<>(getDayOptions());
//        checkoutYearComboBox = new JComboBox<>(getYearOptions());
//        checkoutMonthComboBox = new JComboBox<>(getMonthOptions());
//        checkoutDayComboBox = new JComboBox<>(getDayOptions());
    }

    private JPanel createMainPanel(){
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel headerLabel = new JLabel("BOOKING");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(DefaultScreen.WIDTH / 2 - 150, 100, 300, 50);

        JLabel firstNameLabel = new JLabel("First Name: ");
        firstNameLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(firstNameLabel);
        firstNameLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,250,150,30);

        JLabel lastNameLabel = new JLabel("Last Name: ");
        lastNameLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(lastNameLabel);
        lastNameLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,325,150,30);

        JLabel phoneLabel = new JLabel("Phone: ");
        phoneLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(phoneLabel);
        phoneLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,400,150,30);

        JLabel emailLabel = new JLabel("Email: ");
        emailLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(emailLabel);
        emailLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,475,150,30);

        JLabel checkInLabel = new JLabel("Check-In Date: ");
        checkInLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(checkInLabel);
        checkInLabel.setBounds(DefaultScreen.WIDTH / 2 + 100,250,175,30);

        JLabel checkOutLabel = new JLabel("Check-Out Date: ");
        checkOutLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(checkOutLabel);
        checkOutLabel.setBounds(DefaultScreen.WIDTH / 2 + 100,325,175,30);

        JLabel roomCapacityLabel = new JLabel("Room Capacity: ");
        roomCapacityLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(roomCapacityLabel);
        roomCapacityLabel.setBounds(DefaultScreen.WIDTH / 2 + 100,400,175,30);

        firstNameField = new JTextField();
        mainPanel.add(firstNameField);
        firstNameField.setBounds(DefaultScreen.WIDTH / 2 - 300,250,175,30);

        lastNameField = new JTextField();
        mainPanel.add(lastNameField);
        lastNameField.setBounds(DefaultScreen.WIDTH / 2 - 300,325,175,30);

        phoneField = new JTextField();
        mainPanel.add(phoneField);
        phoneField.setBounds(DefaultScreen.WIDTH / 2 - 300,400,175,30);

        emailField = new JTextField();
        mainPanel.add(emailField);
        emailField.setBounds(DefaultScreen.WIDTH / 2 - 300,475,175,30);

        checkInYearComboBox = new JComboBox<>(getYearOptions());
        mainPanel.add(checkInYearComboBox);
        checkInYearComboBox.setBounds(DefaultScreen.WIDTH / 2 + 300,250,75,30);

        checkInMonthComboBox = new JComboBox<>(getMonthOptions());
        mainPanel.add(checkInMonthComboBox);
        checkInMonthComboBox.setBounds(DefaultScreen.WIDTH / 2 + 375,250,75,30);

        checkInDayComboBox = new JComboBox<>(getDayOptions());
        mainPanel.add(checkInDayComboBox);
        checkInDayComboBox.setBounds(DefaultScreen.WIDTH / 2 + 450,250,75,30);

        checkoutYearComboBox = new JComboBox<>(getYearOptions());
        mainPanel.add(checkoutYearComboBox);
        checkoutYearComboBox.setBounds(DefaultScreen.WIDTH / 2 + 300,325,75,30);

        checkoutMonthComboBox = new JComboBox<>(getMonthOptions());
        mainPanel.add(checkoutMonthComboBox);
        checkoutMonthComboBox.setBounds(DefaultScreen.WIDTH / 2 + 375,325,75,30);

        checkoutDayComboBox = new JComboBox<>(getDayOptions());
        mainPanel.add(checkoutDayComboBox);
        checkoutDayComboBox.setBounds(DefaultScreen.WIDTH / 2 + 450,325,75,30);

        roomCapacityComboBox = new JComboBox<>(getRoomCapacityOptions());
        mainPanel.add(roomCapacityComboBox);
        roomCapacityComboBox.setBounds(DefaultScreen.WIDTH / 2 + 300,400,225,30);

        submitButton = new JButton("Submit");
        mainPanel.add(submitButton);
        submitButton.setBounds(625, 575, 100, 40);
        submitButton.setBackground(new Color(143, 188, 143));

        clearButton = new JButton("Clear");
        mainPanel.add(clearButton);
        clearButton.setBounds(850, 575, 100, 40);
        clearButton.setBackground(new Color(192, 192, 192));

        return mainPanel;
    }

//    private JTextField createTextField() {
//        JTextField textField = new JTextField();
//        textField.setEditable(true);
//        textField.setPreferredSize(new Dimension(200, 35));
//        return textField;
//    }

//    private void addLabelAndField(String labelText, JComponent component, int x, int y) {
//        JLabel label = new JLabel(labelText);
//        label.setBounds(x, y, 200, 35);
//        label.setFont(new Font("Tahoma", Font.BOLD, 20));
//
//        add(label);
//
//        component.setBounds(x + 200, y, 200, 30);
//        add(component);
//    }

//    private JPanel dateComboBoxPanel(JComboBox<String> yearComboBox, JComboBox<String> monthComboBox, JComboBox<String> dayComboBox) {
//        JPanel panel = new JPanel(new FlowLayout());
//        panel.setBackground(new Color(113, 146, 172));
//
//        panel.add(yearComboBox);
//        panel.add(monthComboBox);
//        panel.add(dayComboBox);
//
//        int comboBoxWidth = 80;
//        int comboBoxHeight = 30;
//        int spacing = 10;
//
//        // Set bounds for each combo box
//        yearComboBox.setBounds(0, 0, comboBoxWidth, comboBoxHeight);
//        monthComboBox.setBounds(comboBoxWidth + spacing, 0, comboBoxWidth, comboBoxHeight);
//        dayComboBox.setBounds(2 * (comboBoxWidth + spacing), 0, 2 * comboBoxWidth, comboBoxHeight);
//
//
//        yearComboBox.setSelectedIndex(0); // "Year"
//        monthComboBox.setSelectedIndex(0); // "Month"
//        dayComboBox.setSelectedIndex(0); // "Day"
//
//        yearComboBox.setEditable(false);
//        monthComboBox.setEditable(false);
//        dayComboBox.setEditable(false);
//
//        return panel;
//    }
public void displaySuccessMessage(String message) {
    JOptionPane.showMessageDialog(null, message);
}

    public void displayErrorMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }


    private String[] getRoomCapacityOptions() {
        return new String[]{"Choose Room Capacity", "1-2 pax", "2-5 pax", "5-12 pax"};
    }

    private String[] getYearOptions() {
        return new String[]{"Year", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035"};
    }

    private String[] getMonthOptions() {
        return new String[]{"Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
    }

    private String[] getDayOptions() {
        return new String[]{"Day", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"};
    }

    public JTextField getFirstNameField() {
        return firstNameField;
    }

    public JTextField getLastNameField() {
        return lastNameField;
    }

    public JTextField getPhoneField() {
        return phoneField;
    }

    public JTextField getEmailField() {
        return emailField;
    }

    public JButton getSubmitButton() {
        return submitButton;
    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JComboBox<String> getCheckInYearComboBox() {
        return checkInYearComboBox;
    }

    public JComboBox<String> getCheckInMonthComboBox() {
        return checkInMonthComboBox;
    }

    public JComboBox<String> getCheckInDayComboBox() {
        return checkInDayComboBox;
    }

    public JComboBox<String> getCheckOutYearComboBox() {
        return checkoutYearComboBox;
    }

    public JComboBox<String> getCheckOutMonthComboBox() {
        return checkoutMonthComboBox;
    }

    public JComboBox<String> getCheckOutDayComboBox() {
        return checkoutDayComboBox;
    }


    public JComboBox<String> getRoomCapacityComboBox() {
        return roomCapacityComboBox;
    }
}
