package preproject.server.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import preproject.server.controller.ApplicationController;
import preproject.server.model.Account;

import java.awt.*;
import java.awt.event.ActionListener;

import preproject.server.model.*;

public class GuestScreen extends Screen {
    private JTextField searchField;
    private JButton searchButton;
    private JButton deleteButton;
    private JTable table;
    private DefaultTableModel tableModel;

    public GuestScreen() {
        initializeComponents();
        getBackButton().setVisible(false);
    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel headerLabel = new JLabel("GUESTS");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(DefaultScreen.WIDTH / 2 - 50, 10, 100, 30);

        JLabel searchLabel = new JLabel("Search: ");
        mainPanel.add(searchLabel);
        searchLabel.setBounds(10, 20, 60, 20);

        searchField = new JTextField(15);
        mainPanel.add(searchField);
        searchField.setBounds(80, 15, 120, 30);

        searchButton = new JButton("Search");
        mainPanel.add(searchButton);
        searchButton.setBounds(210, 15, 80, 30);

        deleteButton = new JButton("Delete");
        mainPanel.add(deleteButton);
        deleteButton.setBounds(750, 800, 100, 40);
        deleteButton.setBackground(new Color(205, 92, 92));

        // Create the table
        String[] columnNames = {"First Name", "Last Name", "Age", "Phone Number", "Email Address", "Ban Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane);
        scrollPane.setBounds(10, 50, DefaultScreen.WIDTH - 20, DefaultScreen.HEIGHT - 180);

        return mainPanel;
    }

    public void addSearchButtonListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }

    public String getSearchKeyword() {
        return searchField.getText();
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JTable getTable() {
        return table;
    }
    
}
