package preproject.server.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import preproject.server.controller.ApplicationController;
import preproject.server.controller.ViewAppointmentsController;
import preproject.server.model.Booking;

import java.awt.*;
import java.util.List;

public class ViewAppointmentsScreen extends Screen {


    // Fields
    private JLabel titleLabel = new JLabel();
    private DefaultTableModel tableModel;
    private JList<Booking> appointmentList = new JList<>(ApplicationController.appointmentListModel);
    private JScrollPane appointmentScroll = new JScrollPane(appointmentList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    public ViewAppointmentsScreen() {
        getBackButton().setVisible(false);
        setBackground(new Color(113, 146, 172));

        // Title Label
        titleLabel.setText("VIEW BOOKINGS");
        titleLabel.setBounds(570, 60, 1000, 50);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        appointmentList.setFont(new Font("Tahoma", Font.PLAIN, 20));
        appointmentScroll.setBounds(100, 130, 1400, 600);
        add(appointmentScroll);
    }

    public void setAppointmentListData(List<Booking> appointments) {
        ApplicationController.appointmentListModel.clear();
        for (Booking appointment : appointments) {
            ApplicationController.appointmentListModel.addElement(appointment);
        }
    }

    public void setAppointmentData(Booking appointment) {
        ApplicationController.appointmentListModel.addElement(appointment);
    }

    public void clearAppointments() {
        ApplicationController.appointmentListModel.clear();
    }

     public DefaultTableModel getTableModel() {
        return tableModel;
    }
}
