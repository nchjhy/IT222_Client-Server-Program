package preproject.server.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import preproject.server.model.*;

import preproject.server.controller.ApplicationController;

public class BookingHistoryScreen extends Screen {
    private JTextField searchField;
    private JButton searchButton;
    private JTable table;
    private DefaultTableModel tableModel;

    public BookingHistoryScreen() {
        initializeComponents();
        getBackButton().setVisible(false);
    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel headerLabel = new JLabel("BOOKING HISTORY");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(DefaultScreen.WIDTH / 2 - 100, 10, 250, 30);

        JLabel searchLabel = new JLabel("Search: ");
        mainPanel.add(searchLabel);
        searchLabel.setBounds(10, 20, 60, 20);

        searchField = new JTextField(15);
        mainPanel.add(searchField);
        searchField.setBounds(80, 15, 120, 30);

        searchButton = new JButton("Search");
        mainPanel.add(searchButton);
        searchButton.setBounds(210, 15, 80, 30);

        // Create the table
        String[] columnNames = {"First Name", "Last Name", "Phone Number","Email", "Check-in Date", "Check-out Date", "Days Stayed"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane);
        scrollPane.setBounds(10, 50, DefaultScreen.WIDTH - 20, DefaultScreen.HEIGHT - 180);

        return mainPanel;
    }

    public void addSearchButtonListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }

    public String getSearchKeyword() {
        return searchField.getText();
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public DefaultTableModel getTableModel() {
        return tableModel;
    }


}
