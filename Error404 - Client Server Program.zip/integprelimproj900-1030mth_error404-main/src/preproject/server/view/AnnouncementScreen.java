package preproject.server.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnnouncementScreen extends Screen {
    private JTextArea announcementArea = new JTextArea();
    private JButton announceButton = new JButton("Announce");

    public AnnouncementScreen() {
        initializeComponents();
        setLayout(new BorderLayout());
        getBackButton().setVisible(false);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel titleLabel = new JLabel("Announcements!");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(100, 50, 700, 50);
        mainPanel.add(titleLabel);

        announcementArea.setBounds(300, 150, 1000, 300);
        announcementArea.setBackground(new Color(220, 220, 220));
        mainPanel.add(announcementArea);

        announceButton.setBackground(new Color(30, 75, 135));
        announceButton.setForeground(Color.WHITE);
        announceButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        announceButton.setBorder(null);
        announceButton.setBounds(300, 550, 200, 50);
        mainPanel.add(announceButton);

        // Add action listener to the announceButton
        announceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the inputted announcement from the announcementArea
                String announcement = announcementArea.getText();
                // Show the announcement in a message dialog
                showMessage(announcement);
            }
        });

        add(mainPanel);
    }

    private void initializeComponents() {
        announcementArea = new JTextArea();
        announceButton = new JButton("Announce");
    }


    public void showMessage(String announcement) {
        JOptionPane.showMessageDialog(this, "Announcement:\n" + announcement, "Announcement", JOptionPane.INFORMATION_MESSAGE);
    }

    public JTextArea getAnnoucementArea() {
        return announcementArea;
    }

    public JButton getAnnouceButton() {
        return announceButton;
    }
}
