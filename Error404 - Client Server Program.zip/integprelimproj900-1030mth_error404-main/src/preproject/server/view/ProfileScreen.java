package preproject.server.view;

import javax.swing.*;
import java.awt.*;

public class ProfileScreen extends Screen {

    // Fields
    private JLabel profileTitleLabel = new JLabel(new ImageIcon("src/preproject/utilities/pictures/profileTitle.png"));
    private JLabel nameLabel = new JLabel("Name: ");
    private JLabel phoneNumberLabel = new JLabel("Phone Number: ");
    private JLabel emailLabel = new JLabel("Email: ");
    private JLabel passwordLabel = new JLabel("Password: •••••••");
    
    private JLabel icons = new JLabel(new ImageIcon("src/preproject/utilities/pictures/profileIcons.png"));

    private static final Font FONT = new Font("Tahoma", Font.PLAIN, 30);

    public ProfileScreen() {
        getBackButton().setVisible(false);

        profileTitleLabel.setBounds(500, 0, 1600, 900);
        add(profileTitleLabel);

        nameLabel.setBounds(625, 230, 500, 50);
        nameLabel.setFont(FONT);
        add(nameLabel);

        phoneNumberLabel.setBounds(625, 530, 500, 50);
        phoneNumberLabel.setFont(FONT);
        add(phoneNumberLabel);

        emailLabel.setBounds(625, 430, 500, 50);
        emailLabel.setFont(FONT);
        add(emailLabel);

        passwordLabel.setBounds(625, 330, 500, 50);
        passwordLabel.setFont(FONT);
        add(passwordLabel);

        icons.setBounds(0, -5, 1600, 900);
        add(icons);

    }

    public JLabel getNameLabel() { return nameLabel; }

    public JLabel getPhoneNumberLabel() { return phoneNumberLabel; }

    public JLabel getEmailLabel() { return emailLabel; }
  
}