package preproject.server.view;


import javax.swing.*;
import java.awt.*;

public class CheckoutScreen extends Screen {
    private JTextField roomNoField;
    private JButton checkOutButton, clearButton;

    public CheckoutScreen() {
        initializeComponents();
        setLayout(new BorderLayout());
        getBackButton().setVisible(false);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel titleLabel = new JLabel("CHECK-OUT");
        titleLabel.setBounds(665, 70, 500, 50);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);


        JLabel roomNoLabel = new JLabel("ROOM NUMBER: ");
        roomNoLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
        roomNoLabel.setBounds(650, 260, 700, 50);
        mainPanel.add(roomNoLabel);
        roomNoField.setBounds(735, 330, 150, 60);
        mainPanel.add(roomNoField);

        mainPanel.add(checkOutButton);
        checkOutButton.setBounds(850, 460, 110,45);
        mainPanel.add(clearButton);
        clearButton.setBounds(650,460,110,45);

        add(mainPanel);
    

    }

    private void initializeComponents() {
        roomNoField = new JTextField();
        checkOutButton = new JButton("Check-Out");
        checkOutButton.setBackground(new Color(205, 92, 92));
        clearButton = new JButton("Clear");
        clearButton.setBackground(new Color(192, 192, 192));
    }

    public String getRoomNo() {
        return roomNoField.getText();
    }

    public void clearFields() {
        roomNoField.setText("");
    }

    private void performCheckOut() {
        // Implement check-out logic
        JOptionPane.showMessageDialog(CheckoutScreen.this, "Check-out Sucessful");
    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JButton getCheckouButton() {
        return checkOutButton;
    }

}

