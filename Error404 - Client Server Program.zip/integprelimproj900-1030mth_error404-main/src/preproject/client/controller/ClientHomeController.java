package preproject.client.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import preproject.client.view.ClientHomeScreen;
import preproject.server.controller.ApplicationController;
import preproject.server.model.ScreenType;

public class ClientHomeController implements ActionListener {

    private ClientHomeScreen clientHomeScreen; // Access home screen

    // Constructor
    public ClientHomeController(ClientHomeScreen clientHomeScreen) {
        this.clientHomeScreen = clientHomeScreen;
        setupListeners();
    }

    // Welcome label with accounts first name
    public void setupLabel() {
        clientHomeScreen.getWelcomeLabel().setText("Welcome, " + ApplicationController.currentFirstName + "!" );
    }

    // Set up listeners
    public void setupListeners() {
        clientHomeScreen.getBookingButton().addActionListener(this);
        clientHomeScreen.getProfileButton().addActionListener(this);
        clientHomeScreen.getAnnouncementButton().addActionListener(this);
        clientHomeScreen.getLogoutButton().addActionListener((this));
        clientHomeScreen.getViewBookingButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == clientHomeScreen.getBookingButton()) { // Book appointment button
            ApplicationController.switchScreen // Switch to booking screen
                    (ApplicationController.screens[ScreenType.CHECKIN_SCREEN.getValue()]);

        } else if (e.getSource() == clientHomeScreen.getLogoutButton()) { // Logout button
            ApplicationController.switchScreen
                    (ApplicationController.screens[ScreenType.LOGIN_SCREEN.getValue()]);

       } else if (e.getSource() == clientHomeScreen.getAnnouncementButton()) { // View announcement button
            ApplicationController.switchScreen // Switch to view appointments screen
                    (ApplicationController.screens[ScreenType.ANNOUNCEMENT_SCREEN.getValue()]); 
    
       } else if (e.getSource() == clientHomeScreen.getViewBookingButton()) {// View Booking button
            ApplicationController.switchScreen // Switch to profile screen
                    (ApplicationController.screens[ScreenType.CLIENTBOOKINGHISTORY_SCREEN.getValue()]);

       } else if (e.getSource() == clientHomeScreen.getProfileButton()) // Profile button
            ApplicationController.switchScreen // Switch to profile screen
                    (ApplicationController.screens[ScreenType.PROFILE_SCREEN.getValue()]);


    } 
}

