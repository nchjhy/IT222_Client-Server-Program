package preproject.client.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import preproject.client.view.ClientBookingHistoryScreen;
import preproject.server.view.BookingHistoryScreen;

public class ClientBookingHistoryController implements ActionListener {
    private ClientBookingHistoryScreen clientBookingHistoryScreen;

    public ClientBookingHistoryController(ClientBookingHistoryScreen clientBookingHistoryScreen) {
        this.clientBookingHistoryScreen = clientBookingHistoryScreen;

        // Attach ActionListener to the search button
        clientBookingHistoryScreen.addSearchButtonListener(this);
        // Attach ActionListener to the back button
        clientBookingHistoryScreen.getBackButton().addActionListener(this);

        // Populate the table initially
        updateTableModel("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == clientBookingHistoryScreen.getSearchButton()) {
            // Perform search based on the entered keyword
            String keyword = clientBookingHistoryScreen.getSearchKeyword();
            
            // Update the table model with search results
            updateTableModel(keyword);
    
            // Search by email
            searchByEmail(keyword);
        } else if (e.getSource() == clientBookingHistoryScreen.getBackButton()) {
    }
    }
    

    private void searchByEmail(String email) {
        // Clear existing data in the table model
        clearTableModel();
    
        // Get the table model
        DefaultTableModel tableModel = clientBookingHistoryScreen.getTableModel();
    
        try {
            // Parse the XML file and extract relevant information
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File("accounts/appointments.xml"));
    
            // Get the appointments nodes
            NodeList appointmentNodes = doc.getElementsByTagName("appointment");
    
            // Loop through each appointment node
            for (int i = 0; i < appointmentNodes.getLength(); i++) {
                Node appointmentNode = appointmentNodes.item(i);
                if (appointmentNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element appointmentElement = (Element) appointmentNode;
    
                    // Get appointment information from XML elements
                    String firstName = getElementTextContent(appointmentElement, "firstName");
                    String lastName = getElementTextContent(appointmentElement, "lastName");
                    String phoneNumber = getElementTextContent(appointmentElement, "phoneNumber");
                    String appointmentEmail = getElementTextContent(appointmentElement, "email");
                    String checkInDate = getElementTextContent(appointmentElement, "checkInDate");
                    String checkOutDate = getElementTextContent(appointmentElement, "checkOutDate");
    
                    // Calculate days stayed
                    String daysStayed = calculateDaysStayed(checkInDate, checkOutDate);
    
                    // Check if the booking matches the provided email
                    if (appointmentEmail.equals(email)) {
                        // Add a row to the table model with the booking details
                        tableModel.addRow(new Object[]{firstName, lastName, phoneNumber, appointmentEmail, checkInDate, checkOutDate, daysStayed});
                    }
                }
            }
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void updateTableModel(String keyword) {
        // Clear existing data in the table model
        clearTableModel();

        // Get the table model
        DefaultTableModel tableModel = clientBookingHistoryScreen.getTableModel();

        try {
            // Parse the XML file and extract relevant information
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File("accounts/appointments.xml"));

            // Get the appointments nodes
            NodeList appointmentNodes = doc.getElementsByTagName("appointment");

            // Loop through each appointment node
            for (int i = 0; i < appointmentNodes.getLength(); i++) {
                Node appointmentNode = appointmentNodes.item(i);
                if (appointmentNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element appointmentElement = (Element) appointmentNode;

                    // Get appointment information from XML elements
                    String firstName = getElementTextContent(appointmentElement, "firstName");
                    String lastName = getElementTextContent(appointmentElement, "lastName");
                    String phoneNumber = getElementTextContent(appointmentElement, "phoneNumber");
                    String email = getElementTextContent(appointmentElement,"email");
                    String checkInDate = getElementTextContent(appointmentElement, "checkInDate");
                    String checkOutDate = getElementTextContent(appointmentElement, "checkOutDate");

                    // Calculate days stayed
                    String daysStayed = calculateDaysStayed(checkInDate, checkOutDate);

                    // Check if the booking matches the search keyword (if applicable)
                    if (keyword.isEmpty() || firstName.contains(keyword) || lastName.contains(keyword) ||
                            phoneNumber.equals(keyword) || checkInDate.equals(keyword) || checkOutDate.equals(keyword)) {
                        // Add a row to the table model with the booking details
                        tableModel.addRow(new Object[]{firstName, lastName, phoneNumber, email, checkInDate, checkOutDate, daysStayed});
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getElementTextContent(Element appointmentElement, String tagName) {
        NodeList nodeList = appointmentElement.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        } else {
            return "";
        }
    }

    private void clearTableModel() {
        // Remove all rows from the table model
        DefaultTableModel tableModel = clientBookingHistoryScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    }

        // Calculate the number of days stayed
    private String calculateDaysStayed(String checkInDate, String checkOutDate) {
        try {
            // Parse the check-in and check-out dates
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate startDate = LocalDate.parse(checkInDate, formatter);
            LocalDate endDate = LocalDate.parse(checkOutDate, formatter);

            // Calculate the difference between the dates
            long daysStayed = ChronoUnit.DAYS.between(startDate, endDate);

            // Return the calculated number of days stayed as a string
            return String.valueOf(daysStayed);
        } catch (Exception e) {
            e.printStackTrace();
            return "N/A"; 
        }
    }
}
