package preproject.client;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import preproject.server.controller.ApplicationController;

public class Client {
    public static String IP_ADDRESS = "";

    public static void run() {
        try (Socket socket = new Socket(IP_ADDRESS, 1234);
        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        Scanner scan = new Scanner(System.in)) {

            System.out.println("Connected to the server");

            // Create an instance of the ApplicationController
            ApplicationController applicationController = new ApplicationController(out);

            // New thread to listen for messages from the server
            new Thread(() -> {
                try {
                    String line;
                    while ((line = in.readLine()) != null) {
                        System.out.println("Server replied: " + line);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

            String userInput;
            while (!(userInput = scan.nextLine()).equalsIgnoreCase("exit")) {
                out.writeObject(userInput);
                out.flush();
                System.out.println("Server replied: " + in.readLine());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void requestServerAddress() {
        new Thread(() -> {
            try (DatagramSocket socket = new DatagramSocket()) {
                System.out.println("Requesting server address");
                socket.setBroadcast(true);
                byte[] sendData = "REQUEST_SERVER_ADDRESS".getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("255.255.255.255"), 12345);
                socket.send(sendPacket);

                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);
                IP_ADDRESS = receivePacket.getAddress().getHostAddress();
                System.out.println("Server found at IP: " + IP_ADDRESS);
            } catch (IOException e) {
                System.err.println("Error during server address request: " + e.getMessage());
            }
        }).start();
    }

    public static void main(String[] args) {
        requestServerAddress();
        run();
    }
}
