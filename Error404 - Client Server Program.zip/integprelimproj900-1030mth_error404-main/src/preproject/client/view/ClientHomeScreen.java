package preproject.client.view;

import javax.swing.*;

import preproject.server.view.Screen;

import java.awt.*;

public class ClientHomeScreen extends Screen {
    private JLabel welcomeLabel = new JLabel("Welcome to Error 404 Transients");
    private JButton profileButton = new JButton("Your Profile", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/user.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton annoucementButton = new JButton("Announcement", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/announce.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton bookingButton = new JButton("Booking", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/booking.png").getImage().getScaledInstance(45, 45,Image.SCALE_DEFAULT)));
    private JButton logoutButton = new JButton("Logout", new ImageIcon((new ImageIcon("src/preproject/utilities/pictures/logout.png").getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT))));
    private JButton viewBookingButton = new JButton("<html>View previous<br/>Bookings</html>", new ImageIcon(new ImageIcon("src/preproject/utilities/pictures/bhistory.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));

    private static final Font FONT = new Font("Tahoma", Font.PLAIN, 30);

    public ClientHomeScreen() {
        getBackToHomeButton().setVisible(false);
        setBackground(new Color(113, 146, 172));

        welcomeLabel.setBounds(70, 50, 700, 100);
        welcomeLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        welcomeLabel.setForeground(Color.WHITE);
        add(welcomeLabel);


        logoutButton.setBackground(new Color(30, 75, 135));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Tahoma", Font.BOLD, 20));
        logoutButton.setBackground(new Color(205, 92, 92));
        logoutButton.setBorder(null);
        logoutButton.setBounds(750, 750, 150, 50);
        add(logoutButton);

        bookingButton.setBackground(new Color(30, 75, 135));
        bookingButton.setForeground(Color.WHITE);
        bookingButton.setFont(FONT);
        bookingButton.setBorder(null);
        bookingButton.setBounds(700, 300, 255, 125);
        add(bookingButton);


        viewBookingButton.setBackground(new Color(30, 75, 135));
        viewBookingButton.setForeground(Color.WHITE);
        viewBookingButton.setFont(FONT);
        viewBookingButton.setBorder(null);
        viewBookingButton.setBounds(1100, 300, 255, 125);
        add(viewBookingButton);

        profileButton.setBackground(new Color(30, 75, 135));
        profileButton.setForeground(Color.WHITE);
        profileButton.setFont(FONT);
        profileButton.setBorder(null);
        profileButton.setBounds(700, 520, 255, 125);
        add(profileButton);

        annoucementButton.setBackground(new Color(30, 75, 135));
        annoucementButton.setForeground(Color.WHITE);
        annoucementButton.setFont(FONT);
        annoucementButton.setBorder(null);
        annoucementButton.setBounds(300, 300, 255, 125);
        add(annoucementButton);


    }

    public JLabel getWelcomeLabel() { return welcomeLabel; }

    public JButton getBookingButton() { return bookingButton; }

    public JButton getProfileButton() { return profileButton; }

    public JButton getLogoutButton(){ return logoutButton; }
    
    public JButton getViewBookingButton() { return viewBookingButton; }

    public JButton getAnnouncementButton() { return annoucementButton; }

}
